#include "RoboKick.h"
#include "power_ctl.h"
#include <avr/interrupt.h>

/* Project Tags, for reading out using the ButtLoad project */
BUTTLOADTAG(ProjName,    "Robot Prototype Kicker Driver");
BUTTLOADTAG(BuildTime,   __TIME__);
BUTTLOADTAG(BuildDate,   __DATE__);
BUTTLOADTAG(LUFAVersion, "LUFA V" LUFA_VERSION_STRING);


/* globals */

/* Kicker State */
#define KickerBackTime	5000

uint16_t KickerSelect = 0;	/* 0 .. 3 */
uint16_t KickerOnTime = 0;	/* 64usec steps */
KickerState_t KickerState,NextKickerState = IDLE;

/* Kicker Endpoint Data */
uint16_t KickerEPData_Select;
uint16_t KickerEPData_OnTime;


/* UnderVoltage Detection */
uint8_t UVD_shift = 0;
PowerState_t PowerState,NextPowerState = UNKNOWN;


/* remove later !!! */
uint16_t counter=0;


int main(void)
{
	//uint8_t i;	/* counter var */

	/* Disable watchdog if enabled by bootloader/fuses */
	MCUSR &= ~(1 << WDRF);
	wdt_disable();

	/* Disable Clock Division */
	SetSystemClockPrescaler(0);

	/* Predefine Kicker values */
	

	/* Hardware Initialization */
	LEDs_Init();

	USB_Init();
	LEDs_TurnOnLEDs(LEDS_LED1);

	InitKicker();
	StopTimer1();

	for(;;)
	{
	}
}


/** Event handler for the USB_Reset event. This fires when the USB interface is reset by the
 *  USB host, before the enumeration process begins, and enables the control endpoint interrupt
 *  so that control requests can be handled asynchronously when they arrive rather than when
 *  the control endpoint is polled manually.
 */
EVENT_HANDLER(USB_Reset)
{
	/* Select the control endpoint */
	Endpoint_SelectEndpoint(ENDPOINT_CONTROLEP);

	/* Enable the endpoint SETUP interrupt ISR for the control endpoint */
	USB_INT_Enable(ENDPOINT_INT_SETUP);
}

/** Event handler for the USB_Connect event. This indicates that the device is enumerating. */
EVENT_HANDLER(USB_Connect)
{
}

/** Event handler for the USB_Disconnect event. This indicates that the device is no longer
 *  connected to a host. Stops the management task.
 */
EVENT_HANDLER(USB_Disconnect)
{
}

/** Event handler for the USB_ConfigurationChanged event. This is fired when the host set the
 *  current configuration of the USB device after enumeration - the device endpoints are configured
 *  and the management task can be started.
 */
EVENT_HANDLER(USB_ConfigurationChanged)
{
	/* Setup In Endpoints */
	Endpoint_ConfigureEndpoint(EP_IN, EP_TYPE_INTERRUPT,
		                       ENDPOINT_DIR_IN, EP_SIZE,
	                           ENDPOINT_BANK_DOUBLE);
	/* Enable the endpoint IN interrupt ISR for the report endpoint */
	USB_INT_Enable(ENDPOINT_INT_IN);

	/* Setup Out Endpoints */
	Endpoint_ConfigureEndpoint(EP_Kicker, EP_TYPE_INTERRUPT,
		                       ENDPOINT_DIR_OUT, EP_Kicker_Size,
	                           ENDPOINT_BANK_SINGLE);
	/* Enable the endpoint OUT interrupt ISR for the LED report endpoint */
	USB_INT_Enable(ENDPOINT_INT_OUT);
}

/** Event handler for the USB_UnhandledControlPacket event. This is used to catch standard and
 *  class specific control requests that are not handled internally by the USB library (including
 *  the Mass Storage class-specific requests) so that they can be handled appropriately for the
 *  application.
 */
EVENT_HANDLER(USB_UnhandledControlPacket)
{
}


/** ISR for the general Pipe/Endpoint interrupt vector. This ISR fires when a control request
 *  has been issued to the control endpoint, so that the request can be processed. As several
 *  elements of the Mass Storage implementation require asynchronous control requests (such as
 *  endpoint stall clearing and Mass Storage Reset requests during data transfers) this is done
 *  via interrupts rather than polling.
 */
ISR(ENDPOINT_PIPE_vect, ISR_BLOCK)
{
	/* Check if the control endpoint has received a request */
	if (Endpoint_HasEndpointInterrupted(ENDPOINT_CONTROLEP))
	{
		/* Clear the endpoint interrupt */
		Endpoint_ClearEndpointInterrupt(ENDPOINT_CONTROLEP);

		/* Process the control request */
		USB_USBTask();

		/* Handshake the endpoint setup interrupt - must be after the call to
                 * USB_USBTask() */
		USB_INT_Clear(ENDPOINT_INT_SETUP);
	}

	if (Endpoint_HasEndpointInterrupted(EP_IN))
	{
		Endpoint_SelectEndpoint(EP_IN);
		/* Clear the endpoint IN interrupt flag */
		USB_INT_Clear(ENDPOINT_INT_IN);
		Endpoint_ClearEndpointInterrupt(EP_IN);
		Endpoint_Write_Word_LE(++counter);
		Endpoint_Write_Word_LE(++counter);
		Endpoint_Write_Word_LE(++counter);
		Endpoint_Write_Word_LE(++counter);
		Endpoint_ClearCurrentBank();
		if Endpoint_ReadWriteAllowed()
		{
			Endpoint_Write_Word_LE(++counter);
			Endpoint_Write_Word_LE(++counter);
			Endpoint_Write_Word_LE(++counter);
			Endpoint_Write_Word_LE(++counter);
			Endpoint_ClearCurrentBank();
		}

	}

	if (Endpoint_HasEndpointInterrupted(EP_Kicker))
	{
		Endpoint_SelectEndpoint(EP_Kicker);
		USB_INT_Clear(ENDPOINT_INT_OUT);
		Endpoint_ClearEndpointInterrupt(EP_Kicker);
		KickerEPData_Select = Endpoint_Read_Word_LE();
		KickerEPData_OnTime = Endpoint_Read_Word_LE();
		Endpoint_ClearCurrentBank();
		if (KickerState == IDLE)
		{
			KickerSelect = KickerEPData_Select;
			KickerOnTime = KickerEPData_OnTime;
			KickerState = KICKING;
			NextKickerState = BACK;
			StartTimer1(KickerOnTime);
			StartKicker(KickerSelect);
		}
	}
}


ISR(TIMER1_COMPA_vect, ISR_BLOCK)
{
	switch (KickerState)
	{
		case KICKING: StopKicker(KickerSelect);
					  NextKickerState = BACK;
					  StopTimer1();
					  StartTimer1(KickerBackTime);
					  break;
		case BACK:	  StopTimer1();
					  NextKickerState =	IDLE;
					  break;
		default:	  NextKickerState =	IDLE;
	}
	KickerState = NextKickerState;
}
