#include <avr/io.h>



/* PC4 .. PC7 <-> IO0 .. IO3 <-> valve0 .. valve3 */
#define IO0				(1 << PC4)
#define IO1				(1 << PC5)
#define IO2				(1 << PC6)
#define IO3				(1 << PC7)	

#define KickerPort		PORTC

typedef enum
{
	IDLE,
	KICKING,
	BACK
} KickerState_t; 

static inline void InitKicker(void)
{
	/* Preset all Kicker-Outputs zero */
	KickerPort &= ~(IO0 | IO1 | IO2 | IO3);
	/* Configure IO0 .. IO3 as output */
	DDRC |= IO0|IO1|IO2|IO3;
}

static inline void StartKicker(int8_t KickerNumber)
{
	switch (KickerNumber)
	{
		case 1: KickerPort |= IO1; break;
		case 2: KickerPort |= IO2; break;
		case 3: KickerPort |= IO3; break;
		default: KickerPort |= IO0;
	}
}

static inline void StopKicker(int8_t KickerNumber)
{
	switch (KickerNumber)
	{
		case 1: KickerPort &= ~IO1; break;
		case 2: KickerPort &= ~IO2; break;
		case 3: KickerPort &= ~IO3; break;
		default: KickerPort &= ~IO0;
	}

}


/* Set Prescaler to generate 64micsosec Timer1 clock period @ F_CPU = 16MHz */
static inline void StartTimer1(uint16_t CaptureTime)
{
	#if F_CPU == 16000000
		OCR1A = CaptureTime >> 1;
	#elif F_CPU == 8000000
		OCR1A = CaptureTime;
    #else
		#error "Wrong F_CPU Setting"
	#endif
		
	TCCR1A = 0;
	TCCR1B = (1 << CS12) | (1 << CS10);	/* F_CPU / 1024 ; start Timer1 */
	TIMSK1 |= (1 << OCF1A);
}

static inline void StopTimer1(void)
{
	/* Stop Timer */
	TCCR1B = 0;
	/* Reset Timer-Value */
	TCNT1 = 0;
	/* Clear Pending Interrupt */
	TIFR1 |= (1 << OCF1A);
	/* Disable Timer1 Compare - Interrupt */
	TIMSK1 &= ~(1 << OCIE1A);	
}
