#include "Descriptors.h"

USB_Descriptor_Device_t PROGMEM DeviceDescriptor =
{
        Header:                 {Size: sizeof(USB_Descriptor_Device_t), Type: DTYPE_Device},

        USBSpecification:       VERSION_BCD(01.10),
        Class:                  0x00,
        SubClass:               0x00,
        Protocol:               0x00,

        Endpoint0Size:          8,

        VendorID:               0x03A3,
        ProductID:              0x2B49,
        ReleaseNumber:          0x0000,

        ManufacturerStrIndex:   0x01,
        ProductStrIndex:        0x02,
        SerialNumStrIndex:      0x03,

        NumberOfConfigurations: 1
};

USB_Descriptor_Configuration_t PROGMEM ConfigurationDescriptor =
{
        Config:
                {
                        Header:                 {Size: sizeof(USB_Descriptor_Configuration_Header_t), Type: DTYPE_Configuration},

                        TotalConfigurationSize: sizeof(USB_Descriptor_Configuration_t),
                        TotalInterfaces:        1,

                        ConfigurationNumber:    1,
                        ConfigurationStrIndex:  NO_DESCRIPTOR,

                        ConfigAttributes:       USB_CONFIG_ATTR_BUSPOWERED,

                        MaxPowerConsumption:    USB_CONFIG_POWER_MA(100)
                },

        Interface:
                {
                        Header:                 {Size: sizeof(USB_Descriptor_Interface_t), Type: DTYPE_Interface},

                        InterfaceNumber:        0,
                        AlternateSetting:       0,

                        TotalEndpoints:         2,

                        Class:                  0xFF,
                        SubClass:               0xFF,
                        Protocol:               0xFF,

                        InterfaceStrIndex:      NO_DESCRIPTOR
                },

        DataInEndpoint:
                {
                        Header:                 {Size: sizeof(USB_Descriptor_Endpoint_t), Type: DTYPE_Endpoint},

                        EndpointAddress:        (ENDPOINT_DESCRIPTOR_DIR_IN | EP_IN),
                        Attributes:             EP_TYPE_INTERRUPT,
                        EndpointSize:           EP_SIZE,
                        PollingIntervalMS:      0x01
                },

        DataOutEndpoint:
                {
                        Header:                 {Size: sizeof(USB_Descriptor_Endpoint_t), Type: DTYPE_Endpoint},

                        EndpointAddress:        (ENDPOINT_DESCRIPTOR_DIR_OUT | EP_Kicker),
                        Attributes:             EP_TYPE_INTERRUPT,
                        EndpointSize:           EP_Kicker_Size,
                        PollingIntervalMS:      0x05
                }
};

USB_Descriptor_String_t PROGMEM LanguageString =
{
        Header:                 {Size: USB_STRING_LEN(1), Type: DTYPE_String},

        UnicodeString:          {LANGUAGE_ID_ENG}
};

USB_Descriptor_String_t PROGMEM ManufacturerString =
{
        Header:                 {Size: USB_STRING_LEN(7), Type: DTYPE_String},

        UnicodeString:          L"UOS/thk"
};


USB_Descriptor_String_t PROGMEM ProductString =
{
        Header:                 {Size: USB_STRING_LEN(11), Type: DTYPE_String},

        UnicodeString:          L"Second Test"
};

USB_Descriptor_String_t PROGMEM SerialNumberString =
{
        Header:                 {Size: USB_STRING_LEN(12), Type: DTYPE_String},

        UnicodeString:          L"000000000000"
};

uint16_t USB_GetDescriptor(const uint16_t wValue, const uint8_t wIndex, void** const DescriptorAddress)
{
        const uint8_t  DescriptorType   = (wValue >> 8);
        const uint8_t  DescriptorNumber = (wValue & 0xFF);

        void*    Address = NULL;
        uint16_t Size    = NO_DESCRIPTOR;

        switch (DescriptorType)
        {
                case DTYPE_Device:
                        Address = DESCRIPTOR_ADDRESS(DeviceDescriptor);
                        Size    = sizeof(USB_Descriptor_Device_t);
                        break;
                case DTYPE_Configuration:
                        Address = DESCRIPTOR_ADDRESS(ConfigurationDescriptor);
                        Size    = sizeof(USB_Descriptor_Configuration_t);
                        break;
                case DTYPE_String:
                        switch (DescriptorNumber)
                        {
                                case 0x00:
                                        Address = DESCRIPTOR_ADDRESS(LanguageString);
                                        Size    = pgm_read_byte(&LanguageString.Header.Size);
                                        break;
                                case 0x01:
                                        Address = DESCRIPTOR_ADDRESS(ManufacturerString);
                                        Size    = pgm_read_byte(&ManufacturerString.Header.Size);
                                        break;
                                case 0x02:
                                        Address = DESCRIPTOR_ADDRESS(ProductString);
                                        Size    = pgm_read_byte(&ProductString.Header.Size);
                                        break;
                                case 0x03:
                                        Address = DESCRIPTOR_ADDRESS(SerialNumberString);
                                        Size    = pgm_read_byte(&SerialNumberString.Header.Size);
                                        break;
                        }

                        break;
        }

        *DescriptorAddress = Address;
        return Size;
}


