#include<avr/io.h>


#define MASTER	( 1 << 7 )
#define UVD		( 1 << 6 )

typedef enum
{
	UNKNOWN,
	POWERGOOD,
	POWERBAD
} PowerState_t

/* PB7 -> MASTER */
static inline void InitMaster(void)
{
	PORTB &= ~MASTER;
	DDRB |= MASTER;
}

static inline void MasterON(void)
{
	PORTB |= MASTER;
}

static inline void MasterOFF(void)
{
	PORTB &= ~MASTER;
}

/* PD6 -> UnderVoltage Detect */
static inline void InitUVD(void)
{
	DDRB &= ~UVD;
}

static inline bool IsVoltageLow(void)
{
	if (PORTB & UVD)
	{
		return(false)
	} else
		return(true)
	}
}
