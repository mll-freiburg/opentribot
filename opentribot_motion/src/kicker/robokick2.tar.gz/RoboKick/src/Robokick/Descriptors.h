#ifndef _DESCRIPTORS_H_
#define _DESCRIPTORS_H_
#endif

#include <../../LUFA/Drivers/USB/USB.h>
#include <avr/pgmspace.h>

#define EP_IN	3
#define EP_Kicker	4

#define EP_SIZE	16
#define EP_Kicker_Size 4

typedef struct
{
	USB_Descriptor_Configuration_Header_t Config;
	USB_Descriptor_Interface_t            Interface;
	USB_Descriptor_Endpoint_t             DataInEndpoint;
	USB_Descriptor_Endpoint_t             DataOutEndpoint;
} USB_Descriptor_Configuration_t;

/* Function Prototypes: */
uint16_t USB_GetDescriptor(const uint16_t wValue, const uint8_t wIndex, void** const DescriptorAddress)
                  ATTR_WARN_UNUSED_RESULT ATTR_NON_NULL_PTR_ARG(3);




