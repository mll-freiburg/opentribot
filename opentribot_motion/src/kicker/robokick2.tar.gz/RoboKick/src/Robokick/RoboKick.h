#ifndef _BULK_H_
#define _BULK_H_
#endif

#include <avr/io.h>
#include <avr/wdt.h>
#include <avr/interrupt.h>
#include <stdbool.h>
#include <string.h>

#include "Descriptors.h"
#include "kicker.h"

#include <../../LUFA/Version.h>                    // Library Version Information
#include <../../LUFA/Common/ButtLoadTag.h>         // PROGMEM tags readable by the ButtLoad project
#include <../../LUFA/Drivers/USB/USB.h>            // USB Functionality
#include <../../LUFA/Drivers/Board/LEDs.h>

/* Event Handlers: */
/** Indicates that this module will catch the USB_Connect event when thrown by the library. */
HANDLES_EVENT(USB_Connect);

/** Indicates that this module will catch the USB_Disconnect event when thrown by the library. */
HANDLES_EVENT(USB_Disconnect);

/** Indicates that this module will catch the USB_Reset event when thrown by the library. */
HANDLES_EVENT(USB_Reset);

/** Indicates that this module will catch the USB_ConfigurationChanged event when thrown by the library. */
HANDLES_EVENT(USB_ConfigurationChanged);

/** Indicates that this module will catch the USB_UnhandledControlPacket event when thrown by the library. */
HANDLES_EVENT(USB_UnhandledControlPacket);

