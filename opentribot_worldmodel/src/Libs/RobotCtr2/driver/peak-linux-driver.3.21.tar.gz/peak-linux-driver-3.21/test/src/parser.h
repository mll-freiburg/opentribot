#ifndef __PARSER_H__
#define __PARSER_H__

//****************************************************************************
// Copyright (C) 2001,2002,2003,2004  PEAK System-Technik GmbH
//
// linux@peak-system.com 
// www.peak-system.com
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
//
// Maintainer(s): Klaus Hitschler (klaus.hitschler@gmx.de)
//****************************************************************************

//****************************************************************************
//
// parser.h - header of parser which parses the input file and put the messages 
//            into a list
//
// $Log: parser.h,v $
// Revision 1.4  2004/04/11 22:03:29  klaus
// cosmetic changes
//
// Revision 1.3  2003/03/02 10:58:08  klaus
// merged USB thread into main path
//
// Revision 1.2.2.1  2003/02/23 17:50:42  klaus
// adapted to gcc 3.2
//
// Revision 1.2  2002/01/30 20:54:27  klaus
// simple source file header change
//
// Revision 1.1  2002/01/13 18:26:42  klaus
// first release
//
//
//****************************************************************************

//****************************************************************************
// INCLUDES
#include <cstdio>
#include <cstdlib>
#include <cerrno>
#include <ctype.h>
#include <libpcan.h>
#include <list>

//****************************************************************************
// DEFINES

//****************************************************************************
// GLOBALS

//****************************************************************************
// LOCALS

//****************************************************************************
// CODE 

class parser
{
  public:
  parser(void);
  parser(const char *filename);
  ~parser(void);

  int nGetLastError(void);
  void setFileName(const char *filename);
  std::list<TPCANMsg> *Messages(void);
  
  private:
  void skip_blanks(char **ptr);
  int  skip_blanks_and_test_for_CR(char **ptr);
  int  scan_unsigned_number(char **ptr, __u32 *dwResult);
  char scan_char(char **ptr);
  int  parse_input_message(char *buffer, TPCANMsg *Message);
  
  const char *m_szFileName;
  int  m_nLastError;
  std::list<TPCANMsg> m_List;
};

#endif // __PARSER_H__

