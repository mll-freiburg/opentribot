//****************************************************************************
// Copyright (C) 2001,2002,2003,2004  PEAK System-Technik GmbH
//
// linux@peak-system.com
// www.peak-system.com
//
// This part of software is proprietary. It is *not* allowed to
// distribute it. No warranty at all is given.
//
// Maintainer(s): Klaus Hitschler (klaus.hitschler@gmx.de)
//****************************************************************************

//****************************************************************************
//
// cobf.h - obfuscation header
//
// $Log: cobf.h,v $
// Revision 1.31  2005/07/19 18:56:57  klaus
// Prepared for kernels greater and equal than 2.6.12,  release_20050719_?
//
// Revision 1.30  2005/07/04 21:25:44  klaus
// Addes pci_enable_driver() for kernels greater and equal 2.6.10. Removed concurrency between read_proc_mem() and USB read/write. Released release_20050704_x.
//
// Revision 1.29  2005/06/30 19:27:24  klaus
// removed inclusion of conf/modversion.h for kernels >= 2.6.10
//
// Revision 1.28  2005/06/23 20:36:22  klaus
// usb_kill_urb() for kernels >= 2.6.11
//
// Revision 1.27  2005/04/13 20:54:23  klaus
// added option to selective compile for PCAN-PCI, PCAN-ISA, PCAN-Dongle or PCAN-USB
//
// Revision 1.26  2005/04/07 20:49:42  klaus
// error -ENOENT (-2) make no more KERN_ERR
//
// Revision 1.25  2005/02/13 12:36:44  klaus
// increased write buffer for hardware revision >= 7
//
// Revision 1.24  2005/02/12 14:24:16  klaus
// bug removed when CAN_ERR_QXMTFULL was raised even when no queue was filled
//
// Revision 1.23  2005/01/30 21:33:42  klaus
// added simple error message when usb-dongle returns CAN_ERR_QXMTFULL
//
// Revision 1.22  2004/12/16 21:00:36  klaus
// experimental "... context at in_atomic() ..." bug fix, release_20041216
//
// Revision 1.21  2004/12/09 21:23:56  klaus
// serial number + HW-Revision 28 bug fixed
//
// Revision 1.20  2004/11/30 19:33:05  klaus
// release_20041130, timeout in urb_t removed up from kernel 2.6.8, ready for SuSE-9.2
//
// Revision 1.19  2004/11/21 20:33:04  klaus
// test release to get serial number bug
//
// Revision 1.18  2004/10/24 21:17:33  klaus
// release_20041024, timeout in urb_t removed up from kernel 2.6.9
//
// Revision 1.17  2004/09/14 17:57:40  klaus
// Released release_20040915_x
//
// Revision 1.16  2004/09/14 17:53:03  klaus
// Take real names for pcan_hw_X and pcan_hw_Y
//
// Revision 1.15  2004/07/18 14:16:16  klaus
// accept or transmitt DLC while ignoring data content when RTR data
//
// Revision 1.14  2004/05/13 15:32:58  klaus
// devfs is depreciated, moved handling from Makefile to pcan_common.h
//
// Revision 1.13  2004/05/06 18:48:10  klaus
// Improvements triggered by Mandrake distribution 2.6.3-7mdk: MODULE_VERSION macro
//
// Revision 1.12  2004/05/02 15:56:51  klaus
// Last corrections and improvements, especially for Makefile(s) and build scenarios
//
// Revision 1.11  2004/05/02 12:06:02  klaus
// total rebuild of Makefile for KBUILD support for Kernel 2.6
//
// Revision 1.10  2004/04/13 20:33:36  klaus
// FASTSCALE is faster with nearly the same accuracy, use FASTSCALE. obfuscation done.
//
// Revision 1.9  2004/04/13 20:33:35  klaus
// FASTSCALE is faster with nearly the same accuracy, use FASTSCALE. obfuscation done.
//
// Revision 1.8  2004/04/11 22:03:29  klaus
// cosmetic changes
//
// Revision 1.7  2004/04/10 12:25:39  klaus
// merge polished between HEAD and kernel-2.6 branch
//
// Revision 1.6.2.2  2004/04/09 22:56:09  klaus
// parts are usable for kernel 2.2-2.6, last step before join with HEAD
//
// Revision 1.6.2.1  2004/04/09 22:56:09  klaus
// parts are usable for kernel 2.2-2.6, last step before join with HEAD
//
// Revision 1.6  2004/03/04 19:43:55  klaus
// wrong handling of RTR data contents - really -removed
//
// Revision 1.5  2004/03/04 18:51:40  klaus
// wrong handling of RTR data contents removed
//
// Revision 1.4  2003/03/02 12:18:33  klaus
// Release_20030302_?
//
// Revision 1.3  2003/03/02 12:18:33  klaus
// Release_20030302_?
//
// Revision 1.2  2003/03/02 10:46:31  klaus
// merged USB thread into main path
//
// Revision 1.1.2.8  2003/02/24 19:13:01  klaus
// another try with obfuscation
//
// Revision 1.1.2.7  2003/02/24 18:39:16  klaus
// removed Makefile inconsistency
//
// Revision 1.1.2.6  2003/02/23 19:32:10  klaus
// fixed system macro strangeness in cobf processing
//
// Revision 1.1.2.5  2003/02/22 18:19:24  klaus
// small changes
//
// Revision 1.1.2.3  2003/02/22 18:00:08  klaus
// pcan_usb_kernel.c inherits its header from predecessor
//
//****************************************************************************

/* COBF by BB -- obfuscated at Tue Jul 19 20:53:26 2005
*/
#define pcan_l82 typedef
#define pcan_l145 union
#define pcan_c u8
#define pcan_h uc
#define pcan_l47 u32
#define pcan_l40 dw
#define pcan_l45 u16
#define pcan_l90 w
#define pcan_m struct
#define pcan_l116 u64
#define pcan_l29 static
#define pcan_l49 void
#define pcan_o pcandev
#define pcan_b dev
#define pcan_i t
#define pcan_u port
#define pcan_w usb
#define pcan_l59 pvXptr
#define pcan_n DPRINTK
#define pcan_q KERN_DEBUG
#define pcan_l DEVICE_NAME
#define pcan_l122 inline
#define pcan_l57 register
#define pcan_l83 llx
#define pcan_p return
#define pcan_l149 ucStep
#define pcan_f if
#define pcan_l169 get_mtime
#define pcan_l196 pdwInitTime
#define pcan_g int
#define pcan_l106 sizeof
#define pcan_l105 purb_t
#define pcan_l103 purb
#define pcan_l177 context
#define pcan_l52 status
#define pcan_l160 atomic_sub
#define pcan_l95 active_urbs
#define pcan_l97 atomic_set
#define pcan_l68 param_xmit_finished
#define pcan_y pt
#define pcan_l136 ucPhysicallyInstalled
#define pcan_l148 ENODEV
#define pcan_l157 param_urb
#define pcan_l134 FILL_BULK_URB
#define pcan_l89 usb_dev
#define pcan_l172 usb_sndbulkpipe
#define pcan_l138 Endpoint
#define pcan_z ucNumber
#define pcan_l156 timeout
#define pcan_l131 HZ
#define pcan_l143 __usb_submit_urb
#define pcan_l58 KERN_ERR
#define pcan_l38 goto
#define pcan_l28 fail
#define pcan_l26 else
#define pcan_l133 atomic_add
#define pcan_l44 while
#define pcan_l127 atomic_read
#define pcan_l124 schedule
#define pcan_l194 USB_PORT
#define pcan_l161 mdelay
#define pcan_l178 usb_rcvbulkpipe
#define pcan_l92 printk
#define pcan_l147 for
#define pcan_l155 ucDeviceNr
#define pcan_l130 dwSerialNumber
#define pcan_l101 ucRevision
#define pcan_l163 EINVAL
#define pcan_l100 ucMsgLen
#define pcan_l121 TPCANRdMsg
#define pcan_t m
#define pcan_l110 dataPacketCounter
#define pcan_j localID
#define pcan_l159 pcan_fifo_claim_for_put
#define pcan_l108 readFifo
#define pcan_l33 Msg
#define pcan_l115 LEN
#define pcan_l54 MSGTYPE
#define pcan_l158 MSGTYPE_RTR
#define pcan_l170 MSGTYPE_STANDARD
#define pcan_l142 MSGTYPE_EXTENDED
#define pcan_l129 ID
#define pcan_l152 dwTime
#define pcan_l67 DATA
#define pcan_l175 bExtended
#define pcan_l192 pcan_fifo_put_reject
#define pcan_l167 pcan_fifo_put
#define pcan_l126 StatusMsg
#define pcan_l165 MSGTYPE_STATUS
#define pcan_l162 switch
#define pcan_l50 case
#define pcan_l61 wCANStatus
#define pcan_l184 CAN_ERR_QOVERRUN
#define pcan_l84 dwErrorCounter
#define pcan_l168 CAN_ERR_BUSOFF
#define pcan_l195 CAN_ERR_BUSHEAVY
#define pcan_l182 CAN_ERR_BUSLIGHT
#define pcan_l51 break
#define pcan_l186 CAN_ERR_QXMTFULL
#define pcan_l183 default
#define pcan_l128 buffer_dump
#define pcan_l187 EFAULT
#define pcan_l173 wake_up_interruptible
#define pcan_l166 read_queue
#define pcan_l99 nMsgCounter
#define pcan_l164 TPCANMsg
#define pcan_l179 pcan_fifo_claim_for_get
#define pcan_l94 writeFifo
#define pcan_l189 ENODATA
#define pcan_l176 nStored
#define pcan_l188 pcan_fifo_get
#define pcan_l191 dwTelegramCount
