#ifndef __PCAN_DONGLE_H__
#define __PCAN_DONGLE_H__

//****************************************************************************
// Copyright (C) 2001,2002,2003,2004  PEAK System-Technik GmbH
//
// linux@peak-system.com
// www.peak-system.com
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
//
// Maintainer(s): Klaus Hitschler (klaus.hitschler@gmx.de)
//****************************************************************************

//****************************************************************************
//
// all parts to handle device interface specific parts of pcan-dongle
//
// $Log: pcan_dongle.h,v $
// Revision 1.14  2005/04/13 20:54:23  klaus
// added option to selective compile for PCAN-PCI, PCAN-ISA, PCAN-Dongle or PCAN-USB
//
// Revision 1.13  2004/04/11 22:03:29  klaus
// cosmetic changes
//
// Revision 1.12  2003/03/02 10:58:07  klaus
// merged USB thread into main path
//
// Revision 1.11  2003/03/02 10:58:07  klaus
// merged USB thread into main path
//
// Revision 1.10.2.3  2003/01/29 20:34:20  klaus
// release_20030129_a and release_20030129_u released
//
// Revision 1.10.2.2  2003/01/29 20:34:19  klaus
// release_20030129_a and release_20030129_u released
//
// Revision 1.10.2.1  2003/01/28 23:28:26  klaus
// reorderd pcan_usb.c and pcan_usb_kernel.c, tidied up
//
// Revision 1.10  2002/01/30 20:54:27  klaus
// simple source file header change
//
//****************************************************************************

//****************************************************************************
// INCLUDES
#include <src/pcan_main.h>

//****************************************************************************
// DEFINES
int  pcan_create_dongle_devices(char *type, u32 io, u16 irq);

#endif // __PCAN_DONGLE_H__
