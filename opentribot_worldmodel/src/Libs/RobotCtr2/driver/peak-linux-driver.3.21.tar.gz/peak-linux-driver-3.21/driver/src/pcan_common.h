#ifndef __PCAN_COMMON_H__
#define __PCAN_COMMON_H__

//****************************************************************************
// Copyright (C) 2001-2005  PEAK System-Technik GmbH
//
// linux@peak-system.com
// www.peak-system.com
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
//
// Maintainer(s): Klaus Hitschler (klaus.hitschler@gmx.de)
//****************************************************************************

//****************************************************************************
//
// global defines to include in all files this module is made of
// ! this must always the 1st include in all files !
//
// $Log: pcan_common.h,v $
// Revision 1.38  2005/07/19 18:56:57  klaus
// Prepared for kernels greater and equal than 2.6.12,  release_20050719_?
//
// Revision 1.37  2005/07/04 21:25:44  klaus
// Addes pci_enable_driver() for kernels greater and equal 2.6.10. Removed concurrency between read_proc_mem() and USB read/write. Released release_20050704_x.
//
// Revision 1.36  2005/06/30 19:27:24  klaus
// removed inclusion of conf/modversion.h for kernels >= 2.6.10
//
// Revision 1.35  2005/04/13 20:54:23  klaus
// added option to selective compile for PCAN-PCI, PCAN-ISA, PCAN-Dongle or PCAN-USB
//
// Revision 1.34  2005/04/07 20:49:42  klaus
// error -ENOENT (-2) make no more KERN_ERR
//
// Revision 1.33  2005/02/12 14:24:16  klaus
// bug removed when CAN_ERR_QXMTFULL was raised even when no queue was filled
//
//
//****************************************************************************

//****************************************************************************
// DEFINES
#ifndef __KERNEL__
  #define __KERNEL__
#endif
#ifndef MODULE
  #define MODULE
#endif

#include <linux/version.h>  // if this file is not found: please look @ /boot/vmlinuz.version.h and make a symlink

// support for MODVERSIONS
#include <linux/autoconf.h>
#if defined(CONFIG_MODVERSIONS) && !defined(MODVERSIONS)
  #define MODVERSIONS
#endif

#ifdef MODVERSIONS
  #if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)
    #if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,10)
      #include <config/modversions.h>
	#endif
  #else
    #include <linux/modversions.h>
  #endif
#endif

// support for DEVFS - not for kernels >= 2.6
#if (!defined(CONFIG_DEVFS_FS) && !defined(DEVFS_SUPPORT)) || (LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0))
  #undef DEVFS_SUPPORT
#endif

// support for PARPORT_SUBSYSTEM
#if !defined(CONFIG_PARPORT_MODULE) && !defined(CONFIG_PARPORT) && defined(PARPORT_SUBSYSTEM)
  #undef PARPORT_SUBSYSTEM
#endif

// support for USB
#if !defined(CONFIG_USB_MODULE) && !defined(CONFIG_USB) && defined(USB_SUPPORT)
  #undef USB_SUPPORT
#endif


// support only versions 2.2.x and 2.4.x
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,2,0)
  #error "This kernel is too old and not supported"
#elif LINUX_VERSION_CODE < KERNEL_VERSION(2,3,0)
  #define LINUX_22 // LINUX 2.2.x
#else
  #if LINUX_VERSION_CODE < KERNEL_VERSION(2,5,0)
    #define LINUX_24 // >= LINUX 2.4.x && < LINUX 2.6
  #else
    #define LINUX_26 // >= LINUX 2.6
  #endif
#endif

// there were some changes during 2.2.x
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,2,18)
  #define DECLARE_WAIT_QUEUE_HEAD(head) struct wait_queue *head = NULL
  typedef  struct wait_queue *wait_queue_head_t;
  #define init_waitqueue_head(head) (*(head)) = NULL
  #define list_add_tail(x, y) __list_add(x, (y)->prev, y)
#endif

// some preparative defintions for kernel 2.6.x 
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,4,24)
  typedef void irqreturn_t;
  #define IRQ_NONE
  #define IRQ_HANDLED
  #define IRQ_RETVAL(x)
#endif

// switch to disable all printks for not debugging
#ifdef DEBUG
  #define DPRINTK printk
#else
  #define DPRINTK(stuff...)
#endif


//----------------------------------------------------------------------------
// set here the current release of the driver 'Release_date_nr' synchronoes
// with CVS until we have managed that CVS does it itself
#ifdef USB_SUPPORT
#define CURRENT_RELEASE "release_20050719_u"  // $name$
#else
#define CURRENT_RELEASE "release_20050719_a"  // $name$
#endif

#endif // __PCAN_COMMON_H__
