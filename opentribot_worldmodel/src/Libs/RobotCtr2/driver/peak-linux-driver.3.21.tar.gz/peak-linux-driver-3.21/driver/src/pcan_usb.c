//****************************************************************************
// Copyright (C) 2001-2004  PEAK System-Technik GmbH
//
// linux@peak-system.com
// www.peak-system.com
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
//
// Maintainer(s): Klaus Hitschler (klaus.hitschler@gmx.de)
//
// Contributions: Philipp Baer (philipp.baer@informatik.uni-ulm.de)
//                Tom Heinrich
//****************************************************************************

//****************************************************************************
//
// pcan_usb.c - the outer usb parts for pcan-usb support
//
// $Log: pcan_usb.c,v $
// Revision 1.17  2005/07/19 18:56:57  klaus
// Prepared for kernels greater and equal than 2.6.12,  release_20050719_?
//
// Revision 1.16  2005/06/24 17:32:38  klaus
// usb_kill_urb() for kernels >= 2.6.10
//
// Revision 1.15  2005/06/23 20:33:13  klaus
// usb_kill_urb() for kernels >= 2.6.11
//
// Revision 1.14  2005/04/13 20:54:24  klaus
// added option to selective compile for PCAN-PCI, PCAN-ISA, PCAN-Dongle or PCAN-USB
//
// Revision 1.13  2005/04/07 20:49:42  klaus
// error -ENOENT (-2) make no more KERN_ERR
//
// Revision 1.12  2005/02/13 12:36:44  klaus
// increased write buffer for hardware revision >= 7
//
// Revision 1.11  2005/02/12 14:24:16  klaus
// bug removed when CAN_ERR_QXMTFULL was raised even when no queue was filled
//
// Revision 1.10  2004/09/14 17:50:04  klaus
// Take real names for pcan_hw_X and pcan_hw_Y
//
// Revision 1.9  2004/09/13 20:33:29  klaus
// Handles URBs greater than 64 bytes
//
// Revision 1.8  2004/07/18 14:15:54  klaus
// removed 'scheduling while atomic!', accept or transmitt DLC while ignoring data content when RTR data
//
// Revision 1.7  2004/04/13 20:33:36  klaus
// FASTSCALE is faster with nearly the same accuracy, use FASTSCALE. obfuscation done.
//
// Revision 1.6  2004/04/13 20:33:35  klaus
// FASTSCALE is faster with nearly the same accuracy, use FASTSCALE. obfuscation done.
//
// Revision 1.5  2004/04/11 22:03:29  klaus
// cosmetic changes
//
// Revision 1.4  2004/04/10 12:25:39  klaus
// merge polished between HEAD and kernel-2.6 branch
//
// Revision 1.3.2.3  2004/04/09 22:56:09  klaus
// parts are usable for kernel 2.2-2.6, last step before join with HEAD
//
// Revision 1.3.2.2  2004/04/09 22:56:09  klaus
// parts are usable for kernel 2.2-2.6, last step before join with HEAD
//
// Revision 1.3.2.1  2004/03/21 12:09:10  klaus
// first commit for branch to kernel 2.6 code
//
// Revision 1.3  2003/06/22 15:34:51  klaus
// added parts to support devfs provided by Philipp Baer (partially untested)
//
// Revision 1.2  2003/03/02 10:46:31  klaus
// merged USB thread into main path
//
// Revision 1.1.2.36  2003/02/25 20:23:37  klaus
// moved pcan_usb_start() from pcan_open() to pcan_device_open()
//
// Revision 1.1.2.35  2003/02/24 19:12:43  klaus
// added debug message at 'while .. schedule()'
//
// Revision 1.1.2.34  2003/02/23 19:33:06  klaus
// tried to fix "not possible to stop" bug
//
// Revision 1.1.2.33  2003/02/16 19:55:52  klaus
// USB Integration, first non public release
//
// Revision 1.1.2.32  2003/02/16 16:36:16  klaus
// pcan_usb_kernel.c returned to main modules
//
// Revision 1.1.2.31  2003/02/09 13:18:09  klaus
// modifications to support linux 2.2.19 kernels
//
// Revision 1.1.2.30  2003/02/09 13:18:09  klaus
// modifications to support linux 2.2.19 kernels
//
// Revision 1.1.2.29  2003/02/09 10:29:20  klaus
// code cleanup, Release_20030208_x
//
// Revision 1.1.2.28  2003/02/08 19:33:48  klaus
// cosmetic changes
//
// Revision 1.1.2.27  2003/02/08 17:32:43  klaus
// modified to use pcan_usb_kernel as prorietary module
//
// Revision 1.1.2.26  2003/02/05 23:12:19  klaus
// adapted to RedHat 7.2
//
// Revision 1.1.2.25  2003/01/29 20:34:20  klaus
// release_20030129_a and release_20030129_u released
//
//****************************************************************************

//****************************************************************************
// INCLUDES
#include <src/pcan_common.h>     // must always be the 1st include
#include <linux/stddef.h>        // NULL
#include <linux/errno.h>
#include <linux/slab.h>          // kmalloc()

#ifndef LINUX_22
#include <linux/module.h>        // MODULE_DEVICE_TABLE()
#endif

#include <linux/usb.h>

#include <src/pcan_fops.h>
#include <src/pcan_usb.h>
#include <src/pcan_usb_kernel.h>

//****************************************************************************
// DEFINES
#define PCAN_USB_MINOR_BASE 32           // starting point of minors for USB devices
#define PCAN_USB_VENDOR_ID  0x0c72
#define PCAN_USB_PRODUCT_ID 0x000c

#define URB_READ_BUFFER_SIZE      1024   // buffer for read URB data (IN)
#define URB_READ_BUFFER_SIZE_OLD    64   // used length for revision < 7

#define URB_WRITE_BUFFER_SIZE      128   // buffer for write URB (OUT)
#define URB_WRITE_BUFFER_SIZE_OLD   64   // used length for hardware < 7

#define MAX_CYCLES_TO_WAIT_FOR_RELEASE 100  // max no. of schedules before release

//****************************************************************************
// GLOBALS
#ifndef LINUX_22
static struct usb_device_id pcan_usb_ids[] =
{
	{ USB_DEVICE(PCAN_USB_VENDOR_ID, PCAN_USB_PRODUCT_ID) },
	{ }						// Terminating entry
};

MODULE_DEVICE_TABLE (usb, pcan_usb_ids);
#endif

#ifdef LINUX_26
static struct usb_class_driver pcan_class =
{
	.name = "usb/pcan%d",
	.fops = &pcan_fops,
	.mode = S_IFCHR | S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH,
	.minor_base = PCAN_USB_MINOR_BASE,
};
#endif

//****************************************************************************
// LOCALS
static u16 usb_devices = 0;        // the number of accepted usb_devices

//****************************************************************************
// CODE

//****************************************************************************
// get cyclic data from endpoint 2
#ifdef LINUX_26
static void pcan_usb_write_notify(struct urb *purb, struct pt_regs *pregs);
#else
static void pcan_usb_write_notify(purb_t purb);
#endif

static int pcan_usb_write(struct pcandev *dev)
{
  int err = 0;
  USB_PORT *u = &dev->port.usb;
  int nDataLength;
  int m_nCurrentLength;

  DPRINTK(KERN_DEBUG "%s: pcan_usb_write()\n", DEVICE_NAME);

  // don't do anything with non-existent hardware
  if (!dev->ucPhysicallyInstalled)
    return -ENODEV;

  // improvement to control 128 bytes buffers
  m_nCurrentLength    = URB_WRITE_BUFFER_SIZE_OLD;
  err = pcan_hw_EncodeMessage(dev, u->pucWriteBuffer, &m_nCurrentLength);
  if (err || (u->ucRevision < 7))
    nDataLength = m_nCurrentLength;
  else
  {
    m_nCurrentLength     = URB_WRITE_BUFFER_SIZE_OLD;
    err = pcan_hw_EncodeMessage(dev, u->pucWriteBuffer + 64, &m_nCurrentLength);
    nDataLength          = URB_WRITE_BUFFER_SIZE_OLD + m_nCurrentLength;    
  }
  
  // fill the URB and submit
  if (nDataLength)
  {
    FILL_BULK_URB(u->write_data, u->usb_dev,
                  usb_sndbulkpipe(u->usb_dev, u->Endpoint[3].ucNumber),
                  u->pucWriteBuffer, nDataLength, pcan_usb_write_notify, dev);

    // start next urb
    if ((err = __usb_submit_urb(u->write_data)))
    {
      dev->nLastError = err;
      dev->dwErrorCounter++; 
      DPRINTK(KERN_ERR "%s: pcan_usb_write() can't submit! (%d)",DEVICE_NAME, err);
    }
    else
      atomic_add(1, &dev->port.usb.active_urbs);
  }

  // it's no error if I can't get more data but still a packet was sent
  if ((err == -ENODATA) && (nDataLength))
    err = 0;

  return err;
}

//****************************************************************************
// notify functions for read and write data
#ifdef LINUX_26
static void pcan_usb_write_notify(struct urb *purb, struct pt_regs *pregs)
#else
static void pcan_usb_write_notify(purb_t purb)
#endif
{
  int err     = 0;
  u16 wwakeup = 0;
  struct pcandev *dev = purb->context;

  // DPRINTK(KERN_DEBUG "%s: pcan_usb_write_notify() (%d)\n", DEVICE_NAME, purb->status);

  // un-register outstanding urb
  atomic_sub(1, &dev->port.usb.active_urbs);

  // don't count interrupts - count packets
  dev->dwInterruptCounter++;                                

  // do write
  if (!purb->status) // stop with first error
    err = pcan_usb_write(dev);

  if (err)
  {
   if (err == -ENODATA)
     wwakeup++;
   else
   {
     DPRINTK(KERN_DEBUG "%s: unexpected error %d from pcan_usb_write()\n", DEVICE_NAME, err);
     dev->nLastError = err;
     dev->dwErrorCounter++;
     dev->wCANStatus |= CAN_ERR_QXMTFULL; // fatal error!
   }
  }

  if (wwakeup)
  {
    atomic_set(&dev->DataSendReady, 1); // signal to write I'm ready
    wake_up_interruptible(&dev->write_queue);
  }
}

#ifdef LINUX_26
static void pcan_usb_read_notify(struct urb *purb, struct pt_regs *pregs)
#else
static void pcan_usb_read_notify(purb_t purb)
#endif
{
  int err = 0;
	struct pcandev *dev = purb->context;
  USB_PORT *u = &dev->port.usb;

  // DPRINTK(KERN_DEBUG "%s: pcan_usb_read_notify() (%d)\n", DEVICE_NAME, purb->status);

  // un-register outstanding urb
  atomic_sub(1, &dev->port.usb.active_urbs);

  // don't count interrupts - count packets
  dev->dwInterruptCounter++;                                

  // do interleaving read
  if (!purb->status && dev->ucPhysicallyInstalled) // stop with first error
  {
    u8  *m_pucTransferBuffer = purb->transfer_buffer;
    int m_nCurrentLength     = purb->actual_length;

    // buffer interleave to increase speed
    if (m_pucTransferBuffer == u->pucReadBuffer[0])
    {
      FILL_BULK_URB(purb, u->usb_dev,
                    usb_rcvbulkpipe(u->usb_dev, u->Endpoint[2].ucNumber),
                    u->pucReadBuffer[1], u->wReadBufferLength, pcan_usb_read_notify, dev);
    }
    else
    {
      FILL_BULK_URB(purb, u->usb_dev,
                    usb_rcvbulkpipe(u->usb_dev, u->Endpoint[2].ucNumber),
                    u->pucReadBuffer[0], u->wReadBufferLength, pcan_usb_read_notify, dev);
    }

    // start next urb
    if ((err = __usb_submit_urb(purb)))
    {
      dev->nLastError = err; 
      dev->dwErrorCounter++;
      printk(KERN_ERR "%s: pcan_usb_read_notify() can't submit! (%d)",DEVICE_NAME, err);
    }
    else
      atomic_add(1, &dev->port.usb.active_urbs);

		do
		{
    	err = pcan_hw_DecodeMessage(dev, m_pucTransferBuffer, m_nCurrentLength);
			if (err)
			{
				dev->nLastError = err; 
				dev->wCANStatus |=  CAN_ERR_QOVERRUN;
				dev->dwErrorCounter++;
				DPRINTK(KERN_DEBUG "%s: error %d from pcan_hw_DecodeMessage()\n", DEVICE_NAME, err);
			}
			m_pucTransferBuffer += 64;
			m_nCurrentLength    -= 64;
		} while (m_nCurrentLength > 0);
  }
  else
  {
    if (purb->status != -ENOENT)
    {
      printk(KERN_ERR "%s: read data stream torn off caused by ", DEVICE_NAME);
      if (!dev->ucPhysicallyInstalled)
        printk("device plug out!\n");
      else
        printk("err %d!\n", purb->status);
    }
  }
}

//****************************************************************************
// usb resource allocation 
//
static int pcan_usb_allocate_resources(struct pcandev *dev)
{
  int err = 0;
  USB_PORT *u = &dev->port.usb;

  DPRINTK(KERN_DEBUG "%s: pcan_usb_allocate_resources()\n", DEVICE_NAME);

  // allocate X data for comparison
  if (!u->pvXptr)
  {
    if (!(u->pvXptr = kmalloc(pcan_X(), GFP_KERNEL)))
    {
      err = -ENOMEM;
      goto fail;
    }
  }
  dev->wInitStep = 4;

  // make param URB
  u->param_urb = __usb_alloc_urb(0);
  if (!u->param_urb)
    err = -ENOMEM;
  dev->wInitStep = 5;

  // allocate write buffer
  if (u->ucRevision < 7)
    u->pucWriteBuffer =  kmalloc(URB_WRITE_BUFFER_SIZE_OLD, GFP_KERNEL);
  else
    u->pucWriteBuffer =  kmalloc(URB_WRITE_BUFFER_SIZE, GFP_KERNEL);
  if (!u->pucWriteBuffer)
  {
    err = -ENOMEM;
    goto fail;
  }
  dev->wInitStep = 6;

  // make write urb
  u->write_data = __usb_alloc_urb(0);
  if (!u->write_data)
  {
    err = -ENOMEM;
    goto fail;
  }
  dev->wInitStep = 7;

  // reset telegram count
  u->dwTelegramCount = 0;

  // allocate both read buffers for URB
  u->pucReadBuffer[0] =  kmalloc(URB_READ_BUFFER_SIZE * 2, GFP_KERNEL);
  if (!u->pucReadBuffer[0])
  {
    err = -ENOMEM;
    goto fail;
  }
  u->pucReadBuffer[1] = u->pucReadBuffer[0] + URB_READ_BUFFER_SIZE;
  dev->wInitStep = 8;

  // make read urb
  u->read_data = __usb_alloc_urb(0);
  if (!u->read_data)
  {
    err = -ENOMEM;
    goto fail;
  }
  dev->wInitStep = 9;

  // different revisions use different buffer sizes
  if (u->ucRevision < 7)
    u->wReadBufferLength = URB_READ_BUFFER_SIZE_OLD;
  else
    u->wReadBufferLength = URB_READ_BUFFER_SIZE;

  fail:
  return err;
}

//****************************************************************************
// usb resource de-allocation 
//
static int pcan_usb_free_resources(struct pcandev *dev)
{
  int err = 0;
  USB_PORT *u = &dev->port.usb;

  DPRINTK(KERN_DEBUG "%s: pcan_usb_free_resources()\n", DEVICE_NAME);

  // at this point no URB must be pending
  // this is forced at pcan_usb_stop
  switch (dev->wInitStep)
  {
    case 9:
      // free read URB
      usb_free_urb(u->read_data);

    case 8:
      kfree(u->pucReadBuffer[0]);

    case 7:
      // free write urb
      usb_free_urb(u->write_data);

    case 6:
      kfree(u->pucWriteBuffer);

    case 5:
      // free param urb
      usb_free_urb(u->param_urb);

    case 4:
      // remove X information
      if (u->pvXptr)
      {
        kfree(u->pvXptr);
        u->pvXptr = NULL;
      }

      dev->wInitStep = 3;
  }

  return err;
}

//****************************************************************************
// start and stop functions for CAN data IN and OUT
static int pcan_usb_start(struct pcandev *dev)
{
  int err = 0;
  USB_PORT *u = &dev->port.usb;

  DPRINTK(KERN_DEBUG "%s: pcan_usb_start()\n", DEVICE_NAME); 

  FILL_BULK_URB(u->read_data, u->usb_dev,
                usb_rcvbulkpipe(u->usb_dev, u->Endpoint[2].ucNumber),
                u->pucReadBuffer[0], u->wReadBufferLength, pcan_usb_read_notify, dev);

  // submit urb
  if ((err = __usb_submit_urb(u->read_data)))
    printk(KERN_ERR "%s: pcan_usb_start() can't submit! (%d)\n",DEVICE_NAME, err);
  else
    atomic_add(1, &dev->port.usb.active_urbs);

  return err;
}

static int pcan_kill_sync_urb(struct urb *urb)
{
	int err = 0;
	
  if (urb->status == -EINPROGRESS)
  {
  	#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,10)
		usb_kill_urb(urb);
		#else
    err = usb_unlink_urb(urb);
	  #endif
    DPRINTK(KERN_DEBUG "%s: pcan_kill_sync_urb done ...\n", DEVICE_NAME);
  }
  
  return err;
}

static int pcan_usb_stop(struct pcandev *dev)
{
  int err = 0;
  USB_PORT *u = &dev->port.usb;
  int i = MAX_CYCLES_TO_WAIT_FOR_RELEASE;

  DPRINTK(KERN_DEBUG "%s: pcan_usb_stop()\n", DEVICE_NAME); 

  err = pcan_hw_SetCANOff(dev);

  // wait until all has settled
  mdelay(5);

  // unlink URBs
  pcan_kill_sync_urb(u->read_data);
  pcan_kill_sync_urb(u->write_data);
  pcan_kill_sync_urb(u->param_urb);

  // wait until all urbs returned to sender
  // (I hope) this should be no problem because all urb's are unlinked 
  while ((atomic_read(&u->active_urbs) > 0) && (i--))
    schedule();
  if (i <= 0)
  {
    DPRINTK(KERN_ERR "%s: have still active URBs: %d!\n", DEVICE_NAME, atomic_read(&u->active_urbs));
  }

  return err;
}

//****************************************************************************
// remove device resources 
//
static int pcan_usb_cleanup(struct pcandev *dev)
{
  DPRINTK(KERN_DEBUG "%s: pcan_usb_cleanup()\n", DEVICE_NAME);

  if (dev)
  {
    pcan_usb_free_resources(dev);

    switch(dev->wInitStep)
    {
      case 4: 
              #ifdef DEVFS_SUPPORT
              pcan_devfs_unregister(dev);
              #endif
      case 3: usb_devices--;
              pcan_drv.wDeviceCount--;
      case 2: list_del(&dev->list);
      case 1: 
      case 0: dev->wInitStep = 0;
              kfree(dev);
    }
  }
  
  return 0;
}

// dummy entries for request and free irq
static int pcan_usb_req_irq(struct pcandev *dev)
{
  DPRINTK(KERN_DEBUG "%s: pcan_usb_req_irq()\n", DEVICE_NAME);
  return 0;
}

static void pcan_usb_free_irq(struct pcandev *dev)
{
  DPRINTK(KERN_DEBUG "%s: pcan_usb_free_irq()\n", DEVICE_NAME);

  // mis-used here for another purpose
  // pcan_usb_free_irq() calls when the last path to device just closing
  // and the device itself is already plugged out
  if ((dev) && (!dev->ucPhysicallyInstalled))
    pcan_usb_cleanup(dev);
}

// interface depended open and close
static int pcan_usb_open(struct pcandev *dev)
{
  DPRINTK(KERN_DEBUG "%s: pcan_usb_open()\n", DEVICE_NAME);

  return 0;
}

static int pcan_usb_release(struct pcandev *dev)
{
  DPRINTK(KERN_DEBUG "%s: pcan_usb_release()\n", DEVICE_NAME);

  return 0;
}

// emulated device access functions
// call is only possible if device exists
static int pcan_usb_device_open(struct pcandev *dev, u16 btr0btr1, u8 bExtended, u8 bListenOnly)
{
  int err = 0;

  DPRINTK(KERN_DEBUG "%s: pcan_usb_device_open()\n", DEVICE_NAME);

  // first action: turn CAN off
  if ((err = pcan_hw_SetCANOff(dev)))
    goto fail;

  if ((err = pcan_usb_start(dev)))
    goto fail;

  // init hardware specific parts
  if ((err = pcan_hw_Init(dev, btr0btr1, bListenOnly)))
    goto fail;

  // store extended mode (standard still accepted)
  dev->bExtended = bExtended;

  // take a fresh status
  dev->wCANStatus = 0;

  // copy from NT driver
  mdelay(20);

  // last action: turn CAN on
  if ((err = pcan_hw_SetCANOn(dev)))
    goto fail;

  fail:
  return err;
}

static void pcan_usb_device_release(struct pcandev *dev)
{
  DPRINTK(KERN_DEBUG "%s: pcan_usb_device_release()\n", DEVICE_NAME);

  // do not stop usb immediately, give a chance for the PCAN-USB to send this telegram
  schedule();
  mdelay(100);

  pcan_usb_stop(dev);
}

static int pcan_usb_device_write(struct pcandev *dev)
{
  return pcan_usb_write(dev);
}

#ifndef LINUX_26
//****************************************************************************
// special assignment of minors due to PuP
//
static int assignMinorNumber(struct pcandev *dev)
{
  int searchedMinor;
  u8 occupied;
  struct pcandev   *devWork = (struct pcandev *)NULL;
  struct list_head *ptr;

  DPRINTK(KERN_DEBUG "%s: assignMinorNumber()\n", DEVICE_NAME);

  for (searchedMinor = PCAN_USB_MINOR_BASE; searchedMinor < (PCAN_USB_MINOR_BASE + 8); searchedMinor++)
  {
    occupied = 0;

    // loop trough my devices
    for (ptr = pcan_drv.devices.next; ptr != &pcan_drv.devices; ptr = ptr->next)
    {
      devWork = (struct pcandev *)ptr;  

      // stop if it is occupied
      if (devWork->nMinor == searchedMinor)
      {
        occupied = 1;
        break;
      }
    }
    
    // jump out when the first available number is found
    if (!occupied)
      break;
  }

  if (!occupied)
  {
    dev->nMinor = searchedMinor;
    return 0;
  }
  else
  {
    dev->nMinor = -1;
    return -ENXIO;
  }
}
#endif

//****************************************************************************
// propagate getting of serial number to my 'small' interface
//
int  pcan_usb_getSerialNumber(struct pcandev *dev)
{
  if (dev && dev->ucPhysicallyInstalled)
    return pcan_hw_getSNR(dev, &dev->port.usb.dwSerialNumber);
  else
    return -ENODEV;
}

//****************************************************************************
// things todo after plugin or plugout of device (and power on too)
//
#ifdef LINUX_26
static int pcan_usb_plugin(struct usb_interface *interface, const struct usb_device_id *id)
{
  struct pcandev *dev = NULL;
  int    err = 0;
  int    i;
  USB_PORT *u;
	struct usb_host_interface *iface_desc;
	struct usb_endpoint_descriptor *endpoint;
	struct usb_device *usb_dev = interface_to_usbdev(interface);

  DPRINTK(KERN_DEBUG "%s: pcan_usb_plugin(0x%04x, 0x%04x)\n", DEVICE_NAME, 
          usb_dev->descriptor.idVendor, usb_dev->descriptor.idProduct);

  if ((usb_dev->descriptor.idVendor  == PCAN_USB_VENDOR_ID)  && 
      (usb_dev->descriptor.idProduct == PCAN_USB_PRODUCT_ID))
  {
    // take the 1st configuration (it's default)
		if ((err = usb_reset_configuration (usb_dev)) < 0) 
    {
      printk(KERN_ERR "%s: usb_set_configuration() failed!\n", DEVICE_NAME);
      goto reject;
    }
    
    // only 1 interface is supported
    if ((err = usb_set_interface (usb_dev, 0, 0)) < 0) 
    {
      printk(KERN_ERR "%s: usb_set_interface() failed!\n", DEVICE_NAME);
      goto reject;
    }
    
    // allocate memory for my device
    if ((dev = (struct pcandev *)kmalloc(sizeof(struct pcandev), GFP_KERNEL)) == NULL)
    {
      printk(KERN_ERR "%s: pcan_usb_plugin - memory allocation failed!\n", DEVICE_NAME);
			err = -ENOMEM;
      goto reject;
    }
		memset(dev, 0x00, sizeof(*dev));

    dev->wInitStep = 0;

    u   = &dev->port.usb;

    // init structure elements to defaults
    pcan_soft_init(dev, "usb", HW_USB);

    // preset finish flags
    atomic_set(&u->param_xmit_finished, 0);

    // preset active URB counter
    atomic_set(&u->active_urbs, 0);
  
    // override standard device access functions
    dev->device_open      = pcan_usb_device_open;
    dev->device_release   = pcan_usb_device_release;
    dev->device_write     = pcan_usb_device_write;

    // init process wait queues
    init_waitqueue_head(&dev->read_queue);
    init_waitqueue_head(&dev->write_queue);

    // set this before any instructions, fill struct pcandev, part 1  
    dev->wInitStep   = 0;           
    dev->readreg     = NULL;
    dev->writereg    = NULL;
    dev->cleanup     = pcan_usb_cleanup;
    dev->req_irq     = pcan_usb_req_irq;
    dev->free_irq    = pcan_usb_free_irq;
    dev->open        = pcan_usb_open;
    dev->release     = pcan_usb_release;

    // store pointer to kernel supplied usb_dev
    u->usb_dev          = usb_dev;
    u->ucHardcodedDevNr = (u8)(usb_dev->descriptor.bcdDevice & 0xff);
    u->ucRevision       = (u8)(usb_dev->descriptor.bcdDevice >> 8);
    u->pvXptr           = NULL;

    printk(KERN_INFO "%s: usb hardware revision = %d\n", DEVICE_NAME, u->ucRevision);

    // get endpoint addresses (numbers) and associated max data length (only from setting 0)
		iface_desc = &interface->altsetting[0];
    for (i = 0; i < iface_desc->desc.bNumEndpoints; i++)
    {
			endpoint = &iface_desc->endpoint[i].desc;
			
      u->Endpoint[i].ucNumber = endpoint->bEndpointAddress;
      u->Endpoint[i].wDataSz  = endpoint->wMaxPacketSize;
    }

    spin_lock_init(&u->lock);

    init_waitqueue_head(&u->usb_wait_queue);

    dev->wInitStep = 1;

    // add into list of devices
    list_add_tail(&dev->list, &pcan_drv.devices);  // add this device to the list	      
    dev->wInitStep = 2;
    
    // assign the device as plugged in
    dev->ucPhysicallyInstalled = 1;

    pcan_drv.wDeviceCount++;
    usb_devices++; 
    dev->wInitStep = 3;

    if ((err = pcan_usb_allocate_resources(dev)))
      goto reject;

    dev->wInitStep = 4;

		usb_set_intfdata(interface, dev);
    if ((err = usb_register_dev(interface, &pcan_class)) < 0)
		{
			usb_set_intfdata(interface, NULL);
			goto reject;
		}
		
		dev->nMinor = interface->minor;
		
    #ifdef DEVFS_SUPPORT
    pcan_devfs_register(dev);
    #endif
		
    printk(KERN_INFO "%s: usb device minor %d found\n", DEVICE_NAME, dev->nMinor);

    return 0;

    reject:
    pcan_usb_cleanup(dev);
    
    printk(KERN_ERR "%s: pcan_usb_plugin() failed! (%d)\n", DEVICE_NAME, err);
  }
	
  return err;
}
#else
#ifdef LINUX_24
static void *pcan_usb_plugin(struct usb_device *usb_dev, unsigned int interface, const struct usb_device_id *id_table)
#else
static void *pcan_usb_plugin(struct usb_device *usb_dev, unsigned int interface)
#endif
{
  struct pcandev *dev = NULL;
  int    err = 0;
  int    i;
  USB_PORT *u;
  struct usb_interface_descriptor *current_interface_setting;

  DPRINTK(KERN_DEBUG "%s: pcan_usb_plugin(0x%04x, 0x%04x, %d)\n", DEVICE_NAME,
          usb_dev->descriptor.idVendor, usb_dev->descriptor.idProduct, interface);

  if ((usb_dev->descriptor.idVendor  == PCAN_USB_VENDOR_ID)  &&
      (usb_dev->descriptor.idProduct == PCAN_USB_PRODUCT_ID))
  {
    // take the 1st configuration (it's default)
    if (usb_set_configuration (usb_dev, usb_dev->config[0].bConfigurationValue) < 0)
    {
      printk(KERN_ERR "%s: usb_set_configuration() failed!\n", DEVICE_NAME);
      goto reject;
    }

    // only 1 interface is supported
    if (usb_set_interface (usb_dev, 0, 0) < 0)
    {
      printk(KERN_ERR "%s: usb_set_interface() failed!\n", DEVICE_NAME);
      goto reject;
    }
    
    // allocate memory for my device
    if ((dev = (struct pcandev *)kmalloc(sizeof(struct pcandev), GFP_KERNEL)) == NULL)
    {
      printk(KERN_ERR "%s: pcan_usb_plugin - memory allocation failed!\n", DEVICE_NAME);
      goto reject;
    }

    dev->wInitStep = 0;

    u   = &dev->port.usb;

    // init structure elements to defaults
    pcan_soft_init(dev, "usb", HW_USB);

    // preset finish flags
    atomic_set(&u->param_xmit_finished, 0);

    // preset active URB counter
    atomic_set(&u->active_urbs, 0);

    // override standard device access functions
    dev->device_open      = pcan_usb_device_open;
    dev->device_release   = pcan_usb_device_release;
    dev->device_write     = pcan_usb_device_write;

    // init process wait queues
    init_waitqueue_head(&dev->read_queue);
    init_waitqueue_head(&dev->write_queue);

    // set this before any instructions, fill struct pcandev, part 1
    dev->wInitStep   = 0;           
    dev->readreg     = NULL;
    dev->writereg    = NULL;
    dev->cleanup     = pcan_usb_cleanup;
    dev->req_irq     = pcan_usb_req_irq;
    dev->free_irq    = pcan_usb_free_irq;
    dev->open        = pcan_usb_open;
    dev->release     = pcan_usb_release;

    if ((err = assignMinorNumber(dev)))
      goto reject;

    // store pointer to kernel supplied usb_dev
    u->usb_dev          = usb_dev;
    u->ucHardcodedDevNr = (u8)(usb_dev->descriptor.bcdDevice & 0xff);
    u->ucRevision       = (u8)(usb_dev->descriptor.bcdDevice >> 8);
    u->pvXptr           = NULL;

    printk(KERN_INFO "%s: usb hardware revision = %d\n", DEVICE_NAME, u->ucRevision);

    // get endpoint addresses (numbers) and associated max data length
    current_interface_setting = &usb_dev->actconfig->interface->altsetting[usb_dev->actconfig->interface->act_altsetting];
    for (i = 0; i < 4; i++)
    {
      u->Endpoint[i].ucNumber = current_interface_setting->endpoint[i].bEndpointAddress;
      u->Endpoint[i].wDataSz  = current_interface_setting->endpoint[i].wMaxPacketSize;
    }

    spin_lock_init(&u->lock);

    init_waitqueue_head(&u->usb_wait_queue);

    dev->wInitStep = 1;

    // add into list of devices
    list_add_tail(&dev->list, &pcan_drv.devices);  // add this device to the list
    dev->wInitStep = 2;

    // assign the device as plugged in
    dev->ucPhysicallyInstalled = 1;

    pcan_drv.wDeviceCount++;
    usb_devices++; 
    dev->wInitStep = 3;

    if ((err = pcan_usb_allocate_resources(dev)))
      goto reject;

    dev->wInitStep = 4;

    #ifdef DEVFS_SUPPORT
    pcan_devfs_register(dev);
    #endif
		
    printk(KERN_INFO "%s: usb device minor %d found\n", DEVICE_NAME, dev->nMinor);

    return (void *)dev;

    reject:
    pcan_usb_cleanup(dev);
    
    printk(KERN_ERR "%s: pcan_usb_plugin() failed! (%d)\n", DEVICE_NAME, err);
  }

  return NULL;
}
#endif

//****************************************************************************
// is called at plug out of device
//
#ifdef LINUX_26
static void pcan_usb_plugout(struct usb_interface *interface)
{
  struct pcandev *dev = usb_get_intfdata(interface);

  if (dev)
  {
    DPRINTK(KERN_DEBUG "%s: pcan_usb_plugout(%d)\n", DEVICE_NAME, dev->nMinor);

		usb_set_intfdata(interface, NULL);
		
		usb_deregister_dev(interface, &pcan_class);
		
    // mark this device as plugged out
    dev->ucPhysicallyInstalled = 0;

    // do not remove resources if the device is still in use
    if (!dev->nOpenPaths)
      pcan_usb_cleanup(dev);
  }
}
#else
static void pcan_usb_plugout(struct usb_device *usb_dev, void *drv_context)
{
  struct pcandev *dev = (struct pcandev *)drv_context;

  if (dev)
  {
    DPRINTK(KERN_DEBUG "%s: pcan_usb_plugout(%d)\n", DEVICE_NAME, dev->nMinor);

    // mark this device as plugged out
    dev->ucPhysicallyInstalled = 0;

    // do not remove resources if the device is still in use
    if (!dev->nOpenPaths)
      pcan_usb_cleanup(dev);
  }
}
#endif

//****************************************************************************
// small interface to rest of driver, only init and deinit
//
static int pcan_usb_init(void)
{
  DPRINTK(KERN_DEBUG "%s: pcan_usb_init()\n", DEVICE_NAME);

	memset (&pcan_drv.usbdrv, 0, sizeof(pcan_drv.usbdrv));
	
  #if LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,24)
	pcan_drv.usbdrv.owner       = THIS_MODULE;
	#endif
	
  pcan_drv.usbdrv.probe       = pcan_usb_plugin;
  pcan_drv.usbdrv.disconnect  = pcan_usb_plugout;
  pcan_drv.usbdrv.name        = DEVICE_NAME;

  #ifndef LINUX_22
  pcan_drv.usbdrv.id_table    = pcan_usb_ids;
  #endif

  return usb_register(&pcan_drv.usbdrv);
}

void pcan_usb_deinit(void)
{
  DPRINTK(KERN_DEBUG "%s: pcan_usb_deinit()\n", DEVICE_NAME);

  // unregister usb parts, makes a plugout of registered devices
  usb_deregister(&pcan_drv.usbdrv);
}

//----------------------------------------------------------------------------
// init for usb based devices from peak
int pcan_register_usb_devices(void)
{
  int err;

  DPRINTK(KERN_DEBUG "%s: pcan_register_usb_devices()\n", DEVICE_NAME);

  if (!(err = pcan_usb_init()))
  {
    DPRINTK(KERN_DEBUG "%s: pcan_register_usb_devices() is OK\n", DEVICE_NAME);
  }

  return err;
}

 


