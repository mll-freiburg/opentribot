#ifndef __PCAN_USB_KERNEL_H__
#define __PCAN_USB_KERNEL_H__
//****************************************************************************
// Copyright (C) 2001,2002,2003,2004  PEAK System-Technik GmbH
//
// linux@peak-system.com
// www.peak-system.com
//
// This part of software is proprietary
// No warranty is given at all 
//
// Maintainer(s): Klaus Hitschler (klaus.hitschler@gmx.de)
//****************************************************************************

//****************************************************************************
//
// pcan_usb-kernel.h - the inner hidden usb parts header for pcan-usb support
//
// $Log: pcan_usb_kernel.h,v $
// Revision 1.6  2004/09/14 17:50:48  klaus
// Take real names for pcan_hw_X and pcan_hw_Y
//
// Revision 1.5  2004/04/11 22:03:29  klaus
// cosmetic changes
//
// Revision 1.4  2004/04/10 12:25:39  klaus
// merge polished between HEAD and kernel-2.6 branch
//
// Revision 1.3.2.3  2004/04/09 22:56:09  klaus
// parts are usable for kernel 2.2-2.6, last step before join with HEAD
//
// Revision 1.3.2.2  2004/04/09 22:56:09  klaus
// parts are usable for kernel 2.2-2.6, last step before join with HEAD
//
// Revision 1.3.2.1  2004/03/21 12:09:10  klaus
// first commit for branch to kernel 2.6 code
//
// Revision 1.3  2003/03/02 11:09:21  klaus
// removed software distribution limitation in header
//
// Revision 1.2  2003/03/02 10:46:31  klaus
// merged USB thread into main path
//
// Revision 1.1.2.23  2003/02/16 19:55:52  klaus
// USB Integration, first non public release
//
// Revision 1.1.2.22  2003/02/16 16:36:16  klaus
// pcan_usb_kernel.c returned to main modules
//
// Revision 1.1.2.21  2003/02/08 17:32:43  klaus
// modified to use pcan_usb_kernel as prorietary module
//
// Revision 1.1.2.20  2003/02/05 23:19:53  klaus
// resolved strange CVS conflict
//
// Revision 1.1.2.19  2003/02/05 23:15:13  klaus
// adapted to RedHat 7.2
//
// Revision 1.1.2.18  2003/02/05 23:00:11  klaus
// cosmetics in code
//
// Revision 1.1.2.17  2003/02/05 23:00:11  klaus
// cosmetics in code
//
// Revision 1.1.2.16  2003/01/29 20:34:20  klaus
// release_20030129_a and release_20030129_u released
//
// Revision 1.1.2.15  2003/01/29 20:34:20  klaus
// release_20030129_a and release_20030129_u released
//
// Revision 1.1.2.14  2003/01/28 23:28:26  klaus
// reorderd pcan_usb.c and pcan_usb_kernel.c, tidied up
//
// Revision 1.1.2.13  2003/01/26 22:35:39  klaus
// it's not allowed to invoke 2 waits for bulk transfer at the same pipe at the same time
//
//****************************************************************************


//****************************************************************************
// DEFINES

//****************************************************************************
// INCLUDES
#include <linux/types.h>
#include <linux/usb.h>

#include <src/pcan_main.h>

#ifdef LINUX_26
  #define __usb_submit_urb(x) usb_submit_urb(x, GFP_KERNEL)
  #define __usb_alloc_urb(x)  usb_alloc_urb(x, GFP_KERNEL)
  #define FILL_BULK_URB(a, b, c, d, e, f, g) usb_fill_bulk_urb(a, b, c, d, e, (usb_complete_t)f, (void *)g)
#else
  #define __usb_submit_urb(x) usb_submit_urb(x)
  #define __usb_alloc_urb(x)  usb_alloc_urb(x)
#endif

//****************************************************************************
// DEFINES
int pcan_hw_SetCANOn(struct pcandev *dev);
int pcan_hw_SetCANOff(struct pcandev *dev);

int pcan_hw_Init(struct pcandev *dev, u16 btr0btr1, u8 bListenOnly);
int pcan_hw_getSNR(struct pcandev *dev, u32 *pdwSNR);

int pcan_hw_DecodeMessage(struct pcandev *dev, u8 *ucMsgPtr, int lCurrentLength);
int pcan_hw_EncodeMessage(struct pcandev *dev, u8 *ucMsgPtr, int *pnDataLength);

int pcan_X(void);

#endif // __PCAN_USB_KERNEL_H__

