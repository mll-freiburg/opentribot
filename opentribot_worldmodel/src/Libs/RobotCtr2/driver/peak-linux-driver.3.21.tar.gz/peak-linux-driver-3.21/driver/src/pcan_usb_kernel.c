//****************************************************************************
// Copyright (C) 2001,2002,2003,2004  PEAK System-Technik GmbH
//
// linux@peak-system.com
// www.peak-system.com
//
// This part of software is proprietary 
// No warranty is given at all
//
// Maintainer(s): Klaus Hitschler (klaus.hitschler@gmx.de)
//****************************************************************************

//****************************************************************************
//
// pcan_usb-kernel.c - the inner hidden usb parts for pcan-usb support
//
// $Log: pcan_usb_kernel.c,v $
// Revision 1.32  2005/07/19 18:56:57  klaus
// Prepared for kernels greater and equal than 2.6.12,  release_20050719_?
//
// Revision 1.31  2005/07/04 21:25:44  klaus
// Addes pci_enable_driver() for kernels greater and equal 2.6.10. Removed concurrency between read_proc_mem() and USB read/write. Released release_20050704_x.
//
// Revision 1.30  2005/06/30 19:27:24  klaus
// removed inclusion of conf/modversion.h for kernels >= 2.6.10
//
// Revision 1.29  2005/06/23 20:36:22  klaus
// usb_kill_urb() for kernels >= 2.6.11
//
// Revision 1.28  2005/04/13 20:54:24  klaus
// added option to selective compile for PCAN-PCI, PCAN-ISA, PCAN-Dongle or PCAN-USB
//
// Revision 1.27  2005/04/07 20:49:42  klaus
// error -ENOENT (-2) make no more KERN_ERR
//
// Revision 1.26  2005/02/13 12:36:44  klaus
// increased write buffer for hardware revision >= 7
//
// Revision 1.25  2005/02/12 14:24:16  klaus
// bug removed when CAN_ERR_QXMTFULL was raised even when no queue was filled
//
// Revision 1.24  2005/01/30 21:33:42  klaus
// added simple error message when usb-dongle returns CAN_ERR_QXMTFULL
//
// Revision 1.23  2004/12/16 21:00:36  klaus
// experimental "... context at in_atomic() ..." bug fix, release_20041216
//
// Revision 1.22  2004/12/09 21:23:56  klaus
// serial number + HW-Revision 28 bug fixed
//
// Revision 1.21  2004/11/30 19:33:05  klaus
// release_20041130, timeout in urb_t removed up from kernel 2.6.8, ready for SuSE-9.2
//
// Revision 1.20  2004/11/21 20:33:04  klaus
// test release to get serial number bug
//
// Revision 1.19  2004/10/24 21:17:33  klaus
// release_20041024, timeout in urb_t removed up from kernel 2.6.9
//
// Revision 1.18  2004/09/14 17:57:40  klaus
// Released release_20040915_x
//
// Revision 1.17  2004/09/14 17:51:10  klaus
// Take real names for pcan_hw_X and pcan_hw_Y
//
// Revision 1.16  2004/07/18 14:15:54  klaus
// removed 'scheduling while atomic!', accept or transmitt DLC while ignoring data content when RTR data
//
// Revision 1.15  2004/05/13 15:32:58  klaus
// devfs is depreciated, moved handling from Makefile to pcan_common.h
//
// Revision 1.14  2004/05/06 18:48:10  klaus
// Improvements triggered by Mandrake distribution 2.6.3-7mdk: MODULE_VERSION macro
//
// Revision 1.13  2004/05/02 15:56:52  klaus
// Last corrections and improvements, especially for Makefile(s) and build scenarios
//
// Revision 1.12  2004/05/02 12:06:02  klaus
// total rebuild of Makefile for KBUILD support for Kernel 2.6
//
// Revision 1.11  2004/04/13 20:33:36  klaus
// FASTSCALE is faster with nearly the same accuracy, use FASTSCALE. obfuscation done.
//
// Revision 1.10  2004/04/13 20:33:35  klaus
// FASTSCALE is faster with nearly the same accuracy, use FASTSCALE. obfuscation done.
//
// Revision 1.9  2004/04/11 22:03:29  klaus
// cosmetic changes
//
// Revision 1.8  2004/04/10 12:25:39  klaus
// merge polished between HEAD and kernel-2.6 branch
//
// Revision 1.7.2.2  2004/04/09 22:56:09  klaus
// parts are usable for kernel 2.2-2.6, last step before join with HEAD
//
// Revision 1.7.2.1  2004/04/09 22:56:09  klaus
// parts are usable for kernel 2.2-2.6, last step before join with HEAD
//
// Revision 1.7  2004/03/04 19:43:55  klaus
// wrong handling of RTR data contents - really -removed
//
// Revision 1.6  2004/03/04 18:50:41  klaus
// wrong handling of RTR data contents removed
//
// Revision 1.5  2003/03/02 12:18:33  klaus
// Release_20030302_?
//
// Revision 1.4  2003/03/02 12:18:33  klaus
// Release_20030302_?
//
// Revision 1.3  2003/03/02 11:09:21  klaus
// removed software distribution limitation in header
//
// Revision 1.2  2003/03/02 10:46:31  klaus
// merged USB thread into main path
//
// Revision 1.1.2.34  2003/02/24 19:13:01  klaus
// another try with obfuscation
//
// Revision 1.1.2.33  2003/02/24 18:39:16  klaus
// removed Makefile inconsistency
//
// Revision 1.1.2.32  2003/02/23 19:32:10  klaus
// fixed system macro strangeness in cobf processing
//
// Revision 1.1.2.31  2003/02/22 18:19:24  klaus
// small changes
//
// Revision 1.1.2.29  2003/02/22 18:00:08  klaus
// pcan_usb_kernel.c inherits its header from predecessor
//
//****************************************************************************

/* COBF by BB -- obfuscated at Tue Jul 19 20:53:26 2005
*/
#include<src/pcan_common.h>
#include<pcan.h>
#include<src/pcan_fifo.h>
#include<src/pcan_usb_kernel.h>
#include"cobf.h"
pcan_l82 pcan_l145{pcan_c pcan_h[4];pcan_l47 pcan_l40;}pcan_l91;
pcan_l82 pcan_l145{pcan_c pcan_h[2];pcan_l45 pcan_l90;}pcan_l137;
pcan_l82 pcan_m{pcan_c pcan_l117;pcan_c pcan_l113;pcan_c pcan_s[14];}
__attribute__((packed))pcan_l104;pcan_l82 pcan_m{pcan_l116 pcan_l30;
pcan_l116 pcan_l70;pcan_l47 pcan_l64;pcan_l45 pcan_l86;pcan_l45
pcan_l41;pcan_l45 pcan_l71;pcan_c pcan_l63;}pcan_l34;pcan_l29 pcan_l49
pcan_l120(pcan_m pcan_o*pcan_b){pcan_l34*pcan_i=(pcan_l34* )pcan_b->
pcan_u.pcan_w.pcan_l59;pcan_n(pcan_q"\x25\x73\x3a\x20\x72\x65\x73\x65"
"\x74\x5f\x74\x69\x6d\x65\x73\x74\x61\x6d\x70\x28\x29\n",pcan_l);
pcan_i->pcan_l30=0;pcan_i->pcan_l70=0;pcan_i->pcan_l41=0;pcan_i->
pcan_l63=0;pcan_i->pcan_l71=0;pcan_i->pcan_l64=0;pcan_i->pcan_l86=0;}
pcan_l29 pcan_l122 pcan_l47 pcan_l144(pcan_m pcan_o*pcan_b){pcan_l57
pcan_l34*pcan_i=(pcan_l34* )pcan_b->pcan_u.pcan_w.pcan_l59;pcan_l116
pcan_l83;pcan_l83=pcan_i->pcan_l30-pcan_i->pcan_l86;pcan_l83*=44739;
pcan_p(pcan_l47)(pcan_l83>>=20);}pcan_l29 pcan_l122 pcan_l47 pcan_l112
(pcan_m pcan_o*pcan_b){pcan_p((pcan_l34* )pcan_b->pcan_u.pcan_w.
pcan_l59)->pcan_l64+pcan_l144(pcan_b);}pcan_l29 pcan_l49 pcan_l79(
pcan_m pcan_o*pcan_b,pcan_l45 pcan_r,pcan_c pcan_l149){pcan_l57
pcan_l34*pcan_i=(pcan_l34* )pcan_b->pcan_u.pcan_w.pcan_l59;pcan_f(!
pcan_i->pcan_l64){pcan_i->pcan_l64=pcan_l169()- *pcan_b->pcan_l196;
pcan_i->pcan_l86=pcan_r;pcan_i->pcan_l71=pcan_r;pcan_i->pcan_l30=
pcan_r;pcan_i->pcan_l70=pcan_r;}pcan_f(pcan_l149){pcan_i->pcan_l30=
pcan_i->pcan_l70;pcan_i->pcan_l41=pcan_i->pcan_l71;}pcan_i->pcan_l70=
pcan_i->pcan_l30;pcan_i->pcan_l71=pcan_i->pcan_l41;pcan_f(pcan_r<
pcan_i->pcan_l41)pcan_i->pcan_l30+=0x10000LL;pcan_i->pcan_l30&=~
0xFFFFLL;pcan_i->pcan_l30|=pcan_r;pcan_i->pcan_l41=pcan_r;pcan_i->
pcan_l63=(pcan_c)(pcan_r&0xff);}pcan_l29 pcan_l49 pcan_l96(pcan_m
pcan_o*pcan_b,pcan_c pcan_l62){pcan_l57 pcan_l34*pcan_i=(pcan_l34* )pcan_b
->pcan_u.pcan_w.pcan_l59;pcan_f(pcan_l62<pcan_i->pcan_l63){pcan_i->
pcan_l30+=0x100;pcan_i->pcan_l41+=0x100;}pcan_i->pcan_l30&=~0xFFLL;
pcan_i->pcan_l30|=pcan_l62;pcan_i->pcan_l41&=~0xFF;pcan_i->pcan_l41|=
pcan_l62;pcan_i->pcan_l63=pcan_l62;}pcan_g pcan_X(pcan_l49){pcan_p
pcan_l106(pcan_l34);}pcan_l29 pcan_l49 pcan_l102(pcan_l105 pcan_l103){
pcan_m pcan_o*pcan_b=pcan_l103->pcan_l177;pcan_n(pcan_q"\x25\x73\x3a"
"\x20\x70\x63\x61\x6e\x5f\x70\x61\x72\x61\x6d\x5f\x78\x6d\x69\x74\x5f"
"\x6e\x6f\x74\x69\x66\x79\x28\x29\x20\x28\x25\x64\x29\n",pcan_l,
pcan_l103->pcan_l52);pcan_l160(1,&pcan_b->pcan_u.pcan_w.pcan_l95);
pcan_l97(&pcan_b->pcan_u.pcan_w.pcan_l68,1);}pcan_l29 pcan_g pcan_l35
(pcan_m pcan_o*pcan_b,pcan_c pcan_l42,pcan_c pcan_l43,pcan_c pcan_l32
,pcan_c pcan_l39,pcan_c pcan_l77,pcan_c pcan_l78,pcan_c pcan_l76,
pcan_c pcan_l75,pcan_c pcan_l73,pcan_c pcan_l74,pcan_c pcan_l119,
pcan_c pcan_l118,pcan_c pcan_l154,pcan_c pcan_l153,pcan_c pcan_l151,
pcan_c pcan_l150){pcan_l104 pcan_k;pcan_g pcan_l36=0;pcan_l57
pcan_l105 pcan_y;pcan_f(!pcan_b->pcan_l136)pcan_p-pcan_l148;pcan_k.
pcan_l117=pcan_l42;pcan_k.pcan_l113=pcan_l43;pcan_k.pcan_s[0]=
pcan_l32;pcan_k.pcan_s[1]=pcan_l39;pcan_k.pcan_s[2]=pcan_l77;pcan_k.
pcan_s[3]=pcan_l78;pcan_k.pcan_s[4]=pcan_l76;pcan_k.pcan_s[5]=
pcan_l75;pcan_k.pcan_s[6]=pcan_l73;pcan_k.pcan_s[7]=pcan_l74;pcan_k.
pcan_s[8]=pcan_l119;pcan_k.pcan_s[9]=pcan_l118;pcan_k.pcan_s[10]=
pcan_l154;pcan_k.pcan_s[11]=pcan_l153;pcan_k.pcan_s[12]=pcan_l151;
pcan_k.pcan_s[13]=pcan_l150;pcan_y=pcan_b->pcan_u.pcan_w.pcan_l157;
pcan_l134(pcan_y,pcan_b->pcan_u.pcan_w.pcan_l89,pcan_l172(pcan_b->
pcan_u.pcan_w.pcan_l89,pcan_b->pcan_u.pcan_w.pcan_l138[1].pcan_z),&
pcan_k,pcan_l106(pcan_k),pcan_l102,pcan_b);
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,8)
pcan_y->pcan_l156=((1000*pcan_l131)/1000);
#endif
pcan_f(pcan_l143(pcan_y)){pcan_n(pcan_l58"\x25\x73\x3a\x20\x70\x63"
"\x61\x6e\x5f\x73\x65\x74\x5f\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x28"
"\x29\x20\x63\x61\x6e\x27\x74\x20\x73\x75\x62\x6d\x69\x74\x21\n",
pcan_l);pcan_l36=pcan_y->pcan_l52;pcan_l38 pcan_l28;}pcan_l26
pcan_l133(1,&pcan_b->pcan_u.pcan_w.pcan_l95);pcan_l44(!pcan_l127(&
pcan_b->pcan_u.pcan_w.pcan_l68))pcan_l124();pcan_l36=pcan_y->pcan_l52
;pcan_l28:pcan_l97(&pcan_b->pcan_u.pcan_w.pcan_l68,0);pcan_p pcan_l36
;}pcan_l29 pcan_g pcan_l141(pcan_m pcan_o*pcan_b,pcan_c pcan_l42,
pcan_c pcan_l43){pcan_n(pcan_q"\x25\x73\x3a\x20\x70\x63\x61\x6e\x5f"
"\x73\x65\x74\x5f\x66\x75\x6e\x63\x74\x69\x6f\x6e\x28\x25\x64\x2c\x20"
"\x25\x64\x29\n",pcan_l,pcan_l42,pcan_l43);pcan_p pcan_l35(pcan_b,
pcan_l42,pcan_l43,0,0,0,0,0,0,0,0,0,0,0,0,0,0);}pcan_l29 pcan_g
pcan_l53(pcan_m pcan_o*pcan_b,pcan_c pcan_l42,pcan_c pcan_l43,pcan_c*
pcan_l32,pcan_c*pcan_l39,pcan_c*pcan_l77,pcan_c*pcan_l78,pcan_c*
pcan_l76,pcan_c*pcan_l75,pcan_c*pcan_l73,pcan_c*pcan_l74){pcan_l104
pcan_k;pcan_g pcan_l36=0;pcan_l57 pcan_l105 pcan_y;pcan_l194*pcan_l48
=&pcan_b->pcan_u.pcan_w;pcan_n(pcan_q"\x25\x73\x3a\x20\x70\x63\x61"
"\x6e\x5f\x68\x77\x5f\x67\x65\x74\x63\x6f\x6e\x74\x72\x6f\x6c\x5f\x75"
"\x72\x62\x28\x25\x64\x2c\x20\x25\x64\x29\n",pcan_l,pcan_l42,pcan_l43
);pcan_f(!pcan_b->pcan_l136)pcan_p-pcan_l148;pcan_l36=pcan_l141(
pcan_b,pcan_l42,pcan_l43);pcan_l161(5);pcan_f(!pcan_l36){pcan_y=
pcan_l48->pcan_l157;pcan_l134(pcan_y,pcan_l48->pcan_l89,pcan_l178(
pcan_l48->pcan_l89,pcan_l48->pcan_l138[0].pcan_z),&pcan_k,pcan_l106(
pcan_k),pcan_l102,pcan_b);pcan_k.pcan_l117=pcan_l42;pcan_k.pcan_l113=
pcan_l43;
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,8)
pcan_y->pcan_l156=((1000*pcan_l131)/1000);
#endif
pcan_f(pcan_l143(pcan_y)){pcan_l92(pcan_l58"\x25\x73\x3a\x20\x70\x63"
"\x61\x6e\x5f\x67\x65\x74\x5f\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x28"
"\x29\x20\x63\x61\x6e\x27\x74\x20\x73\x75\x62\x6d\x69\x74\x21\n",
pcan_l);pcan_l36=pcan_y->pcan_l52;pcan_l38 pcan_l28;}pcan_l26
pcan_l133(1,&pcan_l48->pcan_l95);pcan_l44(!pcan_l127(&pcan_l48->
pcan_l68))pcan_l124();pcan_f(!pcan_y->pcan_l52){ *pcan_l32=pcan_k.
pcan_s[0]; *pcan_l39=pcan_k.pcan_s[1]; *pcan_l77=pcan_k.pcan_s[2]; *
pcan_l78=pcan_k.pcan_s[3]; *pcan_l76=pcan_k.pcan_s[4]; *pcan_l75=
pcan_k.pcan_s[5]; *pcan_l73=pcan_k.pcan_s[6]; *pcan_l74=pcan_k.pcan_s
[7];}pcan_l36=pcan_y->pcan_l52;}pcan_l28:pcan_l97(&pcan_l48->pcan_l68
,0);pcan_p pcan_l36;}pcan_l29 pcan_g pcan_l135(pcan_m pcan_o*pcan_b,
pcan_l45 pcan_l93){pcan_c pcan_a=0;pcan_c pcan_l32=(pcan_c)(pcan_l93&
0xff);pcan_c pcan_l39=(pcan_c)((pcan_l93>>8)&0xff);pcan_n(pcan_q"\x25"
"\x73\x3a\x20\x70\x63\x61\x6e\x5f\x68\x77\x5f\x73\x65\x74\x42\x54\x52"
"\x30\x42\x54\x52\x31\x28\x30\x78\x25\x30\x34\x78\x29\n",pcan_l,
pcan_l93);pcan_p pcan_l35(pcan_b,1,2,pcan_l32,pcan_l39,pcan_a,pcan_a,
pcan_a,pcan_a,pcan_a,pcan_a,pcan_a,pcan_a,pcan_a,pcan_a,pcan_a,pcan_a
);}pcan_g pcan_hw_SetCANOn(pcan_m pcan_o*pcan_b){pcan_c pcan_a=0;
pcan_n(pcan_q"\x25\x73\x3a\x20\x70\x63\x61\x6e\x5f\x68\x77\x5f\x53"
"\x65\x74\x43\x41\x4e\x4f\x6e\x28\x29\n",pcan_l);pcan_p pcan_l35(
pcan_b,3,2,1,pcan_a,pcan_a,pcan_a,pcan_a,pcan_a,pcan_a,pcan_a,pcan_a,
pcan_a,pcan_a,pcan_a,pcan_a,pcan_a);}pcan_g pcan_hw_SetCANOff(pcan_m
pcan_o*pcan_b){pcan_g pcan_e;pcan_c pcan_a=0;pcan_n(pcan_q"\x25\x73"
"\x3a\x20\x70\x63\x61\x6e\x5f\x68\x77\x5f\x53\x65\x74\x43\x41\x4e\x4f"
"\x66\x66\x28\x29\n",pcan_l);pcan_e=pcan_l35(pcan_b,3,2,0,pcan_a,
pcan_a,pcan_a,pcan_a,pcan_a,pcan_a,pcan_a,pcan_a,pcan_a,pcan_a,pcan_a
,pcan_a,pcan_a);pcan_p pcan_e;}pcan_l29 pcan_g pcan_l146(pcan_m pcan_o
 *pcan_b){pcan_c pcan_a=0;pcan_n(pcan_q"\x25\x73\x3a\x20\x70\x63\x61"
"\x6e\x5f\x68\x77\x5f\x53\x65\x74\x43\x41\x4e\x53\x69\x6c\x65\x6e\x74"
"\x4f\x6e\x28\x29\n",pcan_l);pcan_p pcan_l35(pcan_b,3,3,1,pcan_a,
pcan_a,pcan_a,pcan_a,pcan_a,pcan_a,pcan_a,pcan_a,pcan_a,pcan_a,pcan_a
,pcan_a,pcan_a);}pcan_l29 pcan_g pcan_l125(pcan_m pcan_o*pcan_b){
pcan_c pcan_a=0;pcan_n(pcan_q"\x25\x73\x3a\x20\x70\x63\x61\x6e\x5f"
"\x68\x77\x5f\x53\x65\x74\x43\x41\x4e\x53\x69\x6c\x65\x6e\x74\x4f\x66"
"\x66\x28\x29\n",pcan_l);pcan_p pcan_l35(pcan_b,3,3,0,pcan_a,pcan_a,
pcan_a,pcan_a,pcan_a,pcan_a,pcan_a,pcan_a,pcan_a,pcan_a,pcan_a,pcan_a
,pcan_a);}pcan_g pcan_l190(pcan_m pcan_o*pcan_b,pcan_l45*pcan_l60){
pcan_g pcan_e;pcan_c pcan_a=0;pcan_c pcan_l32=0;pcan_c pcan_l39=0;
pcan_n(pcan_q"\x25\x73\x3a\x20\x70\x63\x61\x6e\x5f\x68\x77\x5f\x67"
"\x65\x74\x42\x54\x52\x30\x42\x54\x52\x31\x28\x29\n",pcan_l);pcan_e=
pcan_l53(pcan_b,1,1,&pcan_l32,&pcan_l39,&pcan_a,&pcan_a,&pcan_a,&
pcan_a,&pcan_a,&pcan_a); *pcan_l60=pcan_l39; *pcan_l60<<=8; *pcan_l60
|=pcan_l32;pcan_n(pcan_q"\x25\x73\x3a\x20\x42\x54\x52\x30\x42\x54\x52"
"\x31\x20\x3d\x20\x30\x78\x25\x30\x34\x78\n",pcan_l, *pcan_l60);
pcan_p pcan_e;}pcan_g pcan_l181(pcan_m pcan_o*pcan_b,pcan_l47*
pcan_l81){pcan_g pcan_e=0;pcan_c pcan_a=0;pcan_c pcan_l32=0;pcan_n(
pcan_q"\x25\x73\x3a\x20\x70\x63\x61\x6e\x5f\x68\x77\x5f\x67\x65\x74"
"\x51\x75\x61\x72\x74\x7a\x28\x29\n",pcan_l);pcan_e=pcan_l53(pcan_b,2
,1,&pcan_l32,&pcan_a,&pcan_a,&pcan_a,&pcan_a,&pcan_a,&pcan_a,&pcan_a);
 *pcan_l81=pcan_l32; *pcan_l81*=1000000L;pcan_n(pcan_q"\x25\x73\x3a"
"\x20\x46\x72\x65\x71\x75\x65\x6e\x7a\x20\x3d\x20\x25\x75\n",pcan_l, *
pcan_l81);pcan_p pcan_e;}pcan_g pcan_l185(pcan_m pcan_o*pcan_b,pcan_c
pcan_l55,pcan_c pcan_z){pcan_g pcan_e=0;pcan_c pcan_a[8];pcan_g
pcan_l27;pcan_n(pcan_q"\x25\x73\x3a\x20\x70\x63\x61\x6e\x5f\x68\x77"
"\x5f\x67\x65\x74\x41\x6e\x79\x74\x68\x69\x6e\x67\x28\x29\n",pcan_l);
pcan_l147(pcan_l27=0;pcan_l27<7;pcan_l27++)pcan_a[pcan_l27]=0;pcan_e=
pcan_l53(pcan_b,pcan_l55,pcan_z,&pcan_a[0],&pcan_a[1],&pcan_a[2],&
pcan_a[3],&pcan_a[4],&pcan_a[5],&pcan_a[6],&pcan_a[7]);pcan_n(pcan_q""
"\x25\x73\x3a\x20\x46\x75\x6e\x2f\x4e\x75\x6d\x3a\x25\x64\x2f\x25\x64"
"\x20\x20\x30\x78\x25\x30\x32\x78\x20\x30\x78\x25\x30\x32\x78\x20\x30"
"\x78\x25\x30\x32\x78\x20\x30\x78\x25\x30\x32\x78\x20\x30\x78\x25\x30"
"\x32\x78\x20\x30\x78\x25\x30\x32\x78\x20\x30\x78\x25\x30\x32\x78\x20"
"\x30\x78\x25\x30\x32\x78\n",pcan_l,pcan_l55,pcan_z,pcan_a[0],pcan_a[
1],pcan_a[2],pcan_a[3],pcan_a[4],pcan_a[5],pcan_a[6],pcan_a[7]);
pcan_p pcan_e;}pcan_g pcan_l174(pcan_m pcan_o*pcan_b,pcan_c*pcan_l98){
pcan_g pcan_e;pcan_c pcan_a=0;pcan_n(pcan_q"\x25\x73\x3a\x20\x70\x63"
"\x61\x6e\x5f\x68\x77\x5f\x67\x65\x74\x44\x65\x76\x69\x63\x65\x4e\x72"
"\x28\x29\n",pcan_l);pcan_e=pcan_l53(pcan_b,4,1,pcan_l98,&pcan_a,&
pcan_a,&pcan_a,&pcan_a,&pcan_a,&pcan_a,&pcan_a);pcan_n(pcan_q"\x25"
"\x73\x3a\x20\x44\x65\x76\x69\x63\x65\x4e\x72\x20\x3d\x20\x30\x78\x25"
"\x30\x32\x78\n",pcan_l, *pcan_l98);pcan_p pcan_e;}pcan_g pcan_l171(
pcan_m pcan_o*pcan_b){pcan_c pcan_a=0;pcan_n(pcan_q"\x25\x73\x3a\x20"
"\x70\x63\x61\x6e\x5f\x68\x77\x5f\x53\x65\x74\x45\x78\x74\x56\x43\x43"
"\x4f\x6e\x28\x29\n",pcan_l);pcan_p pcan_l35(pcan_b,0xA,2,1,pcan_a,
pcan_a,pcan_a,pcan_a,pcan_a,pcan_a,pcan_a,pcan_a,pcan_a,pcan_a,pcan_a
,pcan_a,pcan_a);}pcan_g pcan_l193(pcan_m pcan_o*pcan_b,pcan_c
pcan_l155){pcan_c pcan_a=0;pcan_n(pcan_q"\x25\x73\x3a\x20\x70\x63\x61"
"\x6e\x5f\x68\x77\x5f\x53\x65\x74\x44\x65\x76\x69\x63\x65\x4e\x72\x28"
"\x29\n",pcan_l);pcan_p pcan_l35(pcan_b,4,2,pcan_l155,pcan_a,pcan_a,
pcan_a,pcan_a,pcan_a,pcan_a,pcan_a,pcan_a,pcan_a,pcan_a,pcan_a,pcan_a
,pcan_a);}pcan_g pcan_l180(pcan_m pcan_o*pcan_b,pcan_l47 pcan_l69){
pcan_c pcan_a=0;pcan_n(pcan_q"\x25\x73\x3a\x20\x70\x63\x61\x6e\x5f"
"\x68\x77\x5f\x53\x65\x74\x53\x4e\x52\x28\x29\n",pcan_l);pcan_p
pcan_l35(pcan_b,6,2,(pcan_c)(pcan_l69&0xff),(pcan_c)((pcan_l69>>8)&
0xff),(pcan_c)((pcan_l69>>16)&0xff),(pcan_c)((pcan_l69>>24)&0xff),
pcan_a,pcan_a,pcan_a,pcan_a,pcan_a,pcan_a,pcan_a,pcan_a,pcan_a,pcan_a
);}pcan_l29 pcan_g pcan_l132(pcan_m pcan_o*pcan_b){pcan_c pcan_a=0;
pcan_n(pcan_q"\x25\x73\x3a\x20\x70\x63\x61\x6e\x5f\x68\x77\x5f\x53"
"\x65\x74\x45\x78\x74\x56\x43\x43\x4f\x66\x66\x28\x29\n",pcan_l);
pcan_p pcan_l35(pcan_b,0xA,2,0,pcan_a,pcan_a,pcan_a,pcan_a,pcan_a,
pcan_a,pcan_a,pcan_a,pcan_a,pcan_a,pcan_a,pcan_a,pcan_a);}pcan_g
pcan_hw_getSNR(pcan_m pcan_o*pcan_b,pcan_l47*pcan_l111){pcan_g pcan_e
=0;pcan_l91 pcan_l56;pcan_c pcan_a;pcan_n(pcan_q"\x25\x73\x3a\x20\x70"
"\x63\x61\x6e\x5f\x68\x77\x5f\x67\x65\x74\x53\x4e\x52\x28\x29\n",
pcan_l);pcan_e=pcan_l53(pcan_b,6,1,&pcan_l56.pcan_h[3],&pcan_l56.
pcan_h[2],&pcan_l56.pcan_h[1],&pcan_l56.pcan_h[0],&pcan_a,&pcan_a,&
pcan_a,&pcan_a); *pcan_l111=pcan_l56.pcan_l40;pcan_n(pcan_q"\x25\x73"
"\x3a\x20\x53\x4e\x52\x20\x3d\x20\x30\x78\x25\x30\x38\x78\n",pcan_l, *
pcan_l111);pcan_p pcan_e;}pcan_g pcan_hw_Init(pcan_m pcan_o*pcan_b,
pcan_l45 pcan_l140,pcan_c pcan_l114){pcan_g pcan_e=0;pcan_n(pcan_q""
"\x25\x73\x3a\x20\x70\x63\x61\x6e\x5f\x68\x77\x5f\x49\x6e\x69\x74\x28"
"\x29\n",pcan_l);pcan_e=pcan_hw_getSNR(pcan_b,&pcan_b->pcan_u.pcan_w.
pcan_l130);pcan_f(pcan_e){pcan_b->pcan_u.pcan_w.pcan_l130=0;pcan_l38
pcan_l28;}pcan_e=pcan_l135(pcan_b,pcan_l140);pcan_f(pcan_e)pcan_l38
pcan_l28;pcan_f(pcan_b->pcan_u.pcan_w.pcan_l101>3){pcan_f(pcan_l114)pcan_e
=pcan_l146(pcan_b);pcan_l26 pcan_e=pcan_l125(pcan_b);pcan_f(pcan_e)pcan_l38
pcan_l28;}pcan_l26{pcan_f(pcan_l114){pcan_e=-pcan_l163;pcan_l38
pcan_l28;}}pcan_e=pcan_l132(pcan_b);pcan_l120(pcan_b);pcan_l28:pcan_p
pcan_e;}pcan_g pcan_hw_DecodeMessage(pcan_m pcan_o*pcan_b,pcan_c*
pcan_d,pcan_g pcan_l72){pcan_g pcan_e=0;pcan_g pcan_l27,pcan_l31;
pcan_c pcan_l139;pcan_c pcan_l100;pcan_c pcan_l37=0;pcan_c pcan_x;
pcan_l121*pcan_t;pcan_l137 pcan_r;pcan_c*pcan_l80=pcan_d;pcan_g
pcan_l109=0;pcan_c*pcan_l107=pcan_d;pcan_c pcan_l110=0;pcan_f(!
pcan_l72)pcan_p pcan_e;pcan_l139= *pcan_d++;pcan_l100= *pcan_d++;
pcan_l147(pcan_l27=0;(pcan_l27<pcan_l100);pcan_l27++){pcan_l91 pcan_j
;pcan_l37= *pcan_d++;pcan_f(!(pcan_l37&0x40)){pcan_g pcan_l46;pcan_e=
pcan_l159(&pcan_b->pcan_l108,(pcan_l49* )&pcan_t);pcan_f(pcan_e)pcan_l38
pcan_l28;pcan_x=pcan_l37&0x0F;pcan_f(pcan_x>8)pcan_x=8;pcan_t->
pcan_l33.pcan_l115=pcan_x;pcan_l46=pcan_l37&0x10;pcan_f(pcan_l46)pcan_t
->pcan_l33.pcan_l54=pcan_l158;pcan_l26 pcan_t->pcan_l33.pcan_l54=
pcan_l170;pcan_f(pcan_l37&0x20){pcan_t->pcan_l33.pcan_l54|=pcan_l142;
#ifdef __LITTLE_ENDIAN
pcan_j.pcan_h[0]= *pcan_d++;pcan_j.pcan_h[1]= *pcan_d++;pcan_j.pcan_h
[2]= *pcan_d++;pcan_j.pcan_h[3]= *pcan_d++;
#else
pcan_j.pcan_h[3]= *pcan_d++;pcan_j.pcan_h[2]= *pcan_d++;pcan_j.pcan_h
[1]= *pcan_d++;pcan_j.pcan_h[0]= *pcan_d++;
#endif
pcan_j.pcan_l40>>=3;}pcan_l26{pcan_j.pcan_l40=0;
#ifdef __LITTLE_ENDIAN
pcan_j.pcan_h[0]= *pcan_d++;pcan_j.pcan_h[1]= *pcan_d++;
#else
pcan_j.pcan_h[3]= *pcan_d++;pcan_j.pcan_h[2]= *pcan_d++;
#endif
pcan_j.pcan_l40>>=5;}pcan_t->pcan_l33.pcan_l129=pcan_j.pcan_l40;
pcan_f(!pcan_l110){
#ifdef __LITTLE_ENDIAN
pcan_r.pcan_h[0]= *pcan_d++;pcan_r.pcan_h[1]= *pcan_d++;
#else
pcan_r.pcan_h[1]= *pcan_d++;pcan_r.pcan_h[0]= *pcan_d++;
#endif
pcan_l79(pcan_b,pcan_r.pcan_l90,pcan_l27);}pcan_l26 pcan_l96(pcan_b, *
pcan_d++);pcan_t->pcan_l152=pcan_l112(pcan_b);pcan_l31=0;pcan_f(
pcan_l46){pcan_l44(pcan_x--)pcan_t->pcan_l33.pcan_l67[pcan_l31++]=0;}
pcan_l26{pcan_l44(pcan_x--)pcan_t->pcan_l33.pcan_l67[pcan_l31++]= *
pcan_d++;}pcan_f((!pcan_b->pcan_l175)&&(pcan_l37&0x20)){pcan_e=
pcan_l192(&pcan_b->pcan_l108);pcan_f(pcan_e)pcan_l38 pcan_l28;}
pcan_l26{pcan_e=pcan_l167(&pcan_b->pcan_l108);pcan_f(pcan_e)pcan_l38
pcan_l28;pcan_l109++;}pcan_l110++;}pcan_l26{pcan_l121 pcan_l126;
pcan_c pcan_l55;pcan_c pcan_z;pcan_c pcan_a;pcan_t=&pcan_l126;pcan_t
->pcan_l33.pcan_l54=pcan_l165;pcan_x=pcan_l37&0x0F;pcan_f(pcan_x>8)pcan_x
=8;pcan_t->pcan_l33.pcan_l115=pcan_x;pcan_l55= *pcan_d++;pcan_z= *
pcan_d++;pcan_f(pcan_l37&0x80){pcan_f(!pcan_l27){
#ifdef __LITTLE_ENDIAN
pcan_r.pcan_h[0]= *pcan_d++;pcan_r.pcan_h[1]= *pcan_d++;
#else
pcan_r.pcan_h[1]= *pcan_d++;pcan_r.pcan_h[0]= *pcan_d++;
#endif
pcan_l79(pcan_b,pcan_r.pcan_l90,pcan_l27);}pcan_l26 pcan_l96(pcan_b, *
pcan_d++);}pcan_l162(pcan_l55){pcan_l50 1:pcan_f((pcan_z&0x02)||(
pcan_z&0x40)){pcan_b->pcan_l61|=pcan_l184;pcan_b->pcan_l84++;}pcan_f(
pcan_z&0x10){pcan_b->pcan_l61|=pcan_l168;pcan_b->pcan_l84++;}pcan_f(
pcan_z&0x08){pcan_b->pcan_l61|=pcan_l195;pcan_b->pcan_l84++;}pcan_f(
pcan_z&0x04)pcan_b->pcan_l61|=pcan_l182;pcan_l31=0;pcan_l44(pcan_x--)pcan_t
->pcan_l33.pcan_l67[pcan_l31++]= *pcan_d++;pcan_l51;pcan_l50 2:pcan_a
= *pcan_d++;pcan_a= *pcan_d++;pcan_l51;pcan_l50 3:pcan_a= *pcan_d++;
pcan_l51;pcan_l50 4:
#ifdef __LITTLE_ENDIAN
pcan_r.pcan_h[0]= *pcan_d++;pcan_r.pcan_h[1]= *pcan_d++;
#else
pcan_r.pcan_h[1]= *pcan_d++;pcan_r.pcan_h[0]= *pcan_d++;
#endif
pcan_l79(pcan_b,pcan_r.pcan_l90,pcan_l27);pcan_l51;pcan_l50 5:pcan_f(
pcan_z&0x80){pcan_l92(pcan_l58"\x25\x73\x3a\x20\x51\x55\x45\x55\x45"
"\x5f\x58\x4d\x54\x5f\x46\x55\x4c\x4c\x20\x73\x69\x67\x6e\x61\x6c\x65"
"\x64\x2c\x20\x75\x63\x4e\x75\x6d\x62\x65\x72\x20\x3d\x20\x30\x78\x25"
"\x30\x32\x78\n",pcan_l,pcan_z);pcan_b->pcan_l61|=pcan_l186;pcan_b->
pcan_l84++;}pcan_l31=0;pcan_l44(pcan_x--)pcan_t->pcan_l33.pcan_l67[
pcan_l31++]= *pcan_d++;pcan_l51;pcan_l50 10:pcan_l51;pcan_l183:
pcan_l92(pcan_l58"\x25\x73\x3a\x20\x75\x6e\x65\x78\x70\x65\x63\x74"
"\x65\x64\x20\x66\x75\x6e\x63\x74\x69\x6f\x6e\x2c\x20\x69\x20\x3d\x20"
"\x25\x64\x2c\x20\x75\x63\x53\x74\x61\x74\x75\x73\x4c\x65\x6e\x20\x3d"
"\x20\x30\x78\x25\x30\x32\x78\n",pcan_l,pcan_l27,pcan_l37);pcan_l128(
pcan_l107,4);}pcan_t->pcan_l152=pcan_l112(pcan_b);}pcan_f((pcan_d-
pcan_l80)>pcan_l72){pcan_f((pcan_b->pcan_u.pcan_w.pcan_l101>3)||((
pcan_b->pcan_u.pcan_w.pcan_l101<=3)&&((pcan_d-pcan_l80)>(pcan_l72+1)))){
pcan_e=-pcan_l187;pcan_l92(pcan_l58"\x25\x73\x3a\x20\x49\x6e\x74\x65"
"\x72\x6e\x61\x6c\x20\x45\x72\x72\x6f\x72\x20\x3d\x20\x25\x64\x20\x28"
"\x25\x64\x2c\x20\x25\x64\x29\n",pcan_l,pcan_e,(pcan_d-pcan_l80),
pcan_l72);pcan_l128(pcan_l107,4);pcan_l38 pcan_l28;}}}pcan_f(
pcan_l109)pcan_l173(&pcan_b->pcan_l166);pcan_l28:pcan_p pcan_e;}
pcan_g pcan_hw_EncodeMessage(pcan_m pcan_o*pcan_b,pcan_c*pcan_d,
pcan_g*pcan_l66){pcan_g pcan_e=0;pcan_g pcan_l99=0;pcan_c*pcan_v=
pcan_d;pcan_c pcan_x;pcan_l91 pcan_j;pcan_c*pcan_l65;pcan_c*pcan_l85;
pcan_l164*pcan_t;pcan_g pcan_l31;pcan_c pcan_l87=0;pcan_g pcan_l88= *
pcan_l66;pcan_g pcan_l123=pcan_l88-14; *pcan_l66=0; *pcan_v++=2;
pcan_l85=pcan_v++;pcan_l44(!pcan_l87&&((pcan_v-pcan_d)<pcan_l123)){
pcan_f((pcan_e=pcan_l179(&pcan_b->pcan_l94,(pcan_l49* )&pcan_t))){
pcan_l87=1;pcan_f(pcan_e!=-pcan_l189){pcan_n(pcan_q"\x25\x73\x3a\x20"
"\x63\x61\x6e\x6e\x6f\x74\x20\x63\x6c\x61\x69\x6d\x20\x77\x72\x69\x74"
"\x65\x46\x69\x66\x6f\x2c\x20\x61\x76\x61\x69\x6c\x20\x64\x61\x74\x61"
"\x20\x3d\x20\x25\x64\x2c\x20\x65\x72\x72\x20\x3d\x20\x25\x64\n",
pcan_l,pcan_b->pcan_l94.pcan_l176,pcan_e);}}pcan_l26{pcan_g pcan_l46;
pcan_l65=pcan_v++; *pcan_l65=pcan_x=pcan_t->pcan_l115&0x0F;pcan_l46=
pcan_t->pcan_l54&pcan_l158;pcan_f(pcan_l46) *pcan_l65|=0x10;pcan_l31=
0;pcan_j.pcan_l40=pcan_t->pcan_l129;pcan_f(pcan_t->pcan_l54&pcan_l142
){ *pcan_l65|=0x20;pcan_j.pcan_l40<<=3;
#ifdef __LITTLE_ENDIAN
 *pcan_v++=pcan_j.pcan_h[0]; *pcan_v++=pcan_j.pcan_h[1]; *pcan_v++=
pcan_j.pcan_h[2]; *pcan_v++=pcan_j.pcan_h[3];
#else
 *pcan_v++=pcan_j.pcan_h[3]; *pcan_v++=pcan_j.pcan_h[2]; *pcan_v++=
pcan_j.pcan_h[1]; *pcan_v++=pcan_j.pcan_h[0];
#endif
}pcan_l26{pcan_j.pcan_l40<<=5;
#ifdef __LITTLE_ENDIAN
 *pcan_v++=pcan_j.pcan_h[0]; *pcan_v++=pcan_j.pcan_h[1];
#else
 *pcan_v++=pcan_j.pcan_h[1]; *pcan_v++=pcan_j.pcan_h[0];
#endif
}pcan_f(!pcan_l46){pcan_l31=0;pcan_l44(pcan_x--) *pcan_v++=pcan_t->
pcan_l67[pcan_l31++];}pcan_l99++;pcan_f((pcan_e=pcan_l188(&pcan_b->
pcan_l94)))pcan_l87=1;}}pcan_f((pcan_v-pcan_d)>2){ *pcan_l66=pcan_l88
;pcan_v=pcan_d+pcan_l88-1; *pcan_v=(pcan_c)(pcan_b->pcan_u.pcan_w.
pcan_l191++&0xff); *pcan_l85=pcan_l99;}pcan_l26{ *pcan_l66=0; *
pcan_l85=0;}pcan_p pcan_e;}
