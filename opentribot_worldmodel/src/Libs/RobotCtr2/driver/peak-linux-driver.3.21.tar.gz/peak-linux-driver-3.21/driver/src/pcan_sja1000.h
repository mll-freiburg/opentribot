#ifndef __SJA1000_H__
#define __SJA1000_H__

//****************************************************************************
// Copyright (C) 2001,2002,2003,2004  PEAK System-Technik GmbH
//
// linux@peak-system.com
// www.peak-system.com
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
//
// Maintainer(s): Klaus Hitschler (klaus.hitschler@gmx.de)
//****************************************************************************

//****************************************************************************
//
// sja1000.h - prototypes for sja1000 access functions
//
// $Log: pcan_sja1000.h,v $
// Revision 1.17  2004/04/13 19:43:35  klaus
// release_20040413_x; improved timestamp calculation for USB
//
// Revision 1.16  2004/04/11 22:03:29  klaus
// cosmetic changes
//
// Revision 1.15  2004/04/10 12:25:39  klaus
// merge polished between HEAD and kernel-2.6 branch
//
// Revision 1.14.2.2  2004/03/21 18:41:26  klaus
// interrupt return has changed since 2.4, handler modified
//
// Revision 1.14.2.1  2004/03/21 12:09:09  klaus
// first commit for branch to kernel 2.6 code
//
// Revision 1.14  2003/03/02 10:58:07  klaus
// merged USB thread into main path
//
// Revision 1.13  2003/03/02 10:58:07  klaus
// merged USB thread into main path
//
// Revision 1.12.2.3  2003/01/29 20:34:20  klaus
// release_20030129_a and release_20030129_u released
//
// Revision 1.12.2.2  2003/01/29 20:34:20  klaus
// release_20030129_a and release_20030129_u released
//
// Revision 1.12.2.1  2003/01/28 23:28:26  klaus
// reorderd pcan_usb.c and pcan_usb_kernel.c, tidied up
//
// Revision 1.12  2002/06/11 18:32:56  klaus
// Added pesistence of last init parameters, support for polling operation, support for BTR0BTR1 request, support for kernel 2.4.18
//
//****************************************************************************

//****************************************************************************
// INCLUDES
#include <linux/types.h>
#include <linux/interrupt.h> // 2.6. special
#include <src/pcan_common.h>
#include <src/pcan_main.h>

//****************************************************************************
// DEFINES
int  sja1000_open(struct pcandev *dev, u16 btr0btr1, u8 bExtended, u8 bListenOnly);
void sja1000_release(struct pcandev *dev);
int  sja1000_write(struct pcandev *dev); 

irqreturn_t sja1000_irqhandler(int irq, void *dev_id, struct pt_regs *regs);

int  sja1000_probe(struct pcandev *dev);
u16  sja1000_bitrate(u32 dwBitRate);

#endif //__SJA1000_H__
