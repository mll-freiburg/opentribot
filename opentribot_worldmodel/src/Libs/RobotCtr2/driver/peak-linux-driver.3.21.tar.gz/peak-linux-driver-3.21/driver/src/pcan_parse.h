#ifndef __PCAN_PARSE_H__
#define __PCAN_PARSE_H__

//****************************************************************************
// Copyright (C) 2001,2002,2003,2004  PEAK System-Technik GmbH
//
// linux@peak-system.com
// www.peak-system.com
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
//
// Maintainer(s): Klaus Hitschler (klaus.hitschler@gmx.de)
//****************************************************************************

//****************************************************************************
//
// pcan_parse.h - header for read input parser and write output formatter
//
// $Log: pcan_parse.h,v $
// Revision 1.6  2004/04/11 22:03:29  klaus
// cosmetic changes
//
// Revision 1.5  2003/03/02 10:58:07  klaus
// merged USB thread into main path
//
// Revision 1.4  2003/03/02 10:58:07  klaus
// merged USB thread into main path
//
// Revision 1.3.2.3  2003/01/29 20:34:20  klaus
// release_20030129_a and release_20030129_u released
//
// Revision 1.3.2.2  2003/01/29 20:34:20  klaus
// release_20030129_a and release_20030129_u released
//
// Revision 1.3.2.1  2003/01/28 23:28:26  klaus
// reorderd pcan_usb.c and pcan_usb_kernel.c, tidied up
//
// Revision 1.3  2002/02/11 18:26:32  klaus
// moved libpcan.h and pcan.h to new locations
//
//****************************************************************************

//****************************************************************************
// INCLUDES
#include <pcan.h>

//****************************************************************************
// PROTOTYPES
int pcan_make_output(char *buffer, TPCANRdMsg *m);
int pcan_parse_input_idle(char *buffer);
int pcan_parse_input_message(char *buffer, TPCANMsg *Message);
int pcan_parse_input_init(char *buffer, TPCANInit *Init);

#endif // __PCAN_PARSE_H__

